package it.unibs.elaborato.v1;

import java.io.*;
import java.util.*;

/**
 * Logica di business per la gestione di campi e categorie.
 */
public class Configuratore {
	private List<CampoBase> campiBase = new ArrayList<>();
	private List<CampoComune> campiComuni = new ArrayList<>();
	private Map<String, Categoria> categorie = new HashMap<>();

	// Inizializza i campi base da file o da tastiera se il file è vuoto
	public void caricaCampiBase(String path, Scanner sc) throws IOException {
		File f = new File(path);
		if (!f.exists())
			f.createNewFile();
		BufferedReader br = new BufferedReader(new FileReader(f)) {
			String l;
			while ((l = br.readLine()) != null) {
				if (!l.trim().isEmpty())
					campiBase.add(new CampoBase(l.trim()));
			}
		}
		if (campiBase.isEmpty()) {
			System.out.println("\nPrimo login, inserisci i campi base: ");
			try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
				while (true) {
					System.out.print("Nome campo base (scrivi 'FINE' per terminare): ");
					String nome = sc.nextLine();
					if (nome.equalsIgnoreCase("FINE"))
						break;
					if (!nome.trim().isEmpty()) {
						campiBase.add(new CampoBase(nome.trim()));
						pw.println(nome.trim());
					}
				}
			}
		}
	}

	public void aggiungiCampoComune(String nome, boolean obbligatorietà) {
		campiComuni.add(new CampoComune(nome, obbligatorietà));
	}

	public void rimuoviCampoComune(String nome) {
		campiComuni.removeIf(c -> c.getNome().equalsIgnoreCase(nome));
	}

	public void cambiaObbligatorietaComune(String n, boolean o) {
		for (CampoComune c : campiComuni)
			if (c.getNome().equalsIgnoreCase(n))
				c.setObbligatorio(o);
	}

	public void creaCategoria(String nome) {
		categorie.putIfAbsent(nome, new Categoria(nome));
	}

	public void rimuoviCategoria(String nome) {
		categorie.remove(nome);
	}

	public void aggiungiCampoSpecifico(String cat, String nome, boolean obbligatorio) {
		if (categorie.containsKey(cat))
			categorie.get(cat).aggiungiCampoSpecifico(new CampoSpecifico(nome, obbligatorio));
	}

	public void rimuoviCampoSpecifico(String cat, String nome) {
		if (categorie.containsKey(cat))
			categorie.get(cat).getCampiSpecifici().removeIf(c -> c.getNome().equalsIgnoreCase(nome));
	}
    //metodo per salvare i dati dei campi comuni o delle categorie
	public void salvaDati(String path) {
    PrintWriter pw = null;
    try {
        pw = new PrintWriter(new FileWriter(path));

        pw.println("COMUNI");
        for (CampoComune cc : campiComuni) {
            pw.println(cc.getNome() + ";" + cc.isObbligatorio());
        }

        pw.println("CATEGORIE");
        for (Categoria cat : categorie.values()) {
            pw.print(cat.getNome());
            for (CampoSpecifico cs : cat.getCampiSpecifici()) {
                pw.println(";" + cs.getNome() + "," + cs.isObbligatorio());
            }
        }
        System.out.println("Salvataggio completato con successo.");
    } catch (IOException e) {
        System.err.println("Errore durante il salvataggio: " + e.getMessage());
    } finally {
        pw.close();
        }
    }
    /*
    carica i dati riguardanti i campi 
    */
	public void caricaDati(String path) {
    File f = new File(path);
    if (!f.exists()) {
        return;
    }
    BufferedReader br = null;
    try {
        br = new BufferedReader(new FileReader(f));
        String sezione = "";
        String l;
        while ((l = br.readLine()) != null) {
            if (l.equals("COMUNI") || l.equals("CATEGORIE")) {
                sezione = l;
                continue;
            }
            if (sezione.equals("COMUNI")) {
                String[] p = l.split(";");
                if (p.length >= 2) {
                    campiComuni.add(new CampoComune(p[0], Boolean.parseBoolean(p[1])));
                }
            } else if (sezione.equals("CATEGORIE")) {
                String[] p = l.split(";");
                Categoria c = new Categoria(p[0]);
                for (int i = 1; i < p.length; i++) {
                    String[] d = p[i].split(",");
                    if (d.length >= 2) {
                        c.aggiungiCampoSpecifico(new CampoSpecifico(d[0], Boolean.parseBoolean(d[1])));
                    }
                }
                categorie.put(c.getNome(), c);
            }
        }
    } catch (IOException e) {
        System.err.println("Errore nel caricamento dei dati: " + e.getMessage());
    } finally {
        br.close();
    }

	public List<CampoBase> getCampiBase() {
		return campiBase;
	}

	public List<CampoComune> getCampiComuni() {
		return campiComuni;
	}

	public Collection<Categoria> getCategorie() {
		return categorie.values();
	}
}
