package it.unibs.elaborato.v2;

import java.io.*;
import java.util.*;

/*
    classe che gestisce i metodi alla base delle funzioni di login 
*/
public class SessioneLogin {
	private Map<String, String> utenti = new HashMap<>();
	private static final String Admin = "admin";

    /*confronta se le credenziali di admin sono uguali a quelle inserite da tastiera
    */
	public boolean isAdmin(String nome, String password) {
		return Admin.equals(nome) && Admin.equals(password);
	}
    
    /*controlla se il nome esiste nel file, se esiste confronta la password 
    associata nel file con quella inserita e ritorna vero se coincidono, falso altrimenti
    */
	public boolean autentica(String nome, String password) {
		return utenti.containsKey(nome) && utenti.get(nome).equals(password);
	}

	// se il nome inserito da tastiera è già presente nel file, ritorna falso, altrimenti lo salva e ritorna vero
	public boolean registraNuovo(String nome, String password) {
		if (esisteGia(nome)) {
			return false;
		}
		utenti.put(nome, password);
		return true;
	}
    /*Il metodo confronta se il nome inserito è uguale a uno già presente
       oppure se è uguale a "admin"
    */
	public boolean esisteGia(String nome) {
		return utenti.containsKey(nome) || admin.equalsIgnoreCase(nome);
	}
    /*
    Salva nel file i valori delle mappe riguardanti le credenziali dei configuratori, separandoli con un ;
    */
	public void salva(String path) {
    PrintWriter pw = null;
    try {
        pw = new PrintWriter(new FileWriter(path));
        for (Map.Entry<String, String> voce : utenti.entrySet()) {
            pw.println(voce.getKey() + ";" + voce.getValue());
        }
        System.out.println("Salvataggio completato con successo.");
    } catch (IOException e) {
        System.err.println("Errore durante il salvataggio: " + e.getMessage());
    } finally {
        pw.close();
         }
    }
    /*Legge il file in cui sono salvate le credenziali dei configuratori, controlla 
       che per ogni configuratore ci siano almeno due elementi non vuoti: nome e password
    */
    public void carica(String path) {
        File f = new File(path);
        if (!f.exists()) return;
        BufferedReader br = null;
        try {
            // Tenta di aprire e leggere il file
            br = new BufferedReader(new FileReader(f));
            String l;
            while ((l = br.readLine()) != null) {
                String[] p = l.split(";");
                if (p.length >= 2) {
                    utenti.put(p[0], p[1]);
                }
            }
        } catch (IOException e) {
            System.err.println("Errore durante la lettura del file: " + e.getMessage());
        } finally {
             br.close();
    }   
}
