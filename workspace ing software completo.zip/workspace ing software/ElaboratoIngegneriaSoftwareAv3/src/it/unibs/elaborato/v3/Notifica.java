package it.unibs.elaborato.v3;

import java.time.LocalDate;

/**
 * Avviso formale stampato nella console del Fruitore per segnalare variazioni stato a lui legate.
 * <p><b>Invariante di classe:</b> {@code messaggio != null && data != null}</p>
 */
public class Notifica {
	private String messaggio;
	private LocalDate data;

	/**
	 * Istanzia una ricezione messaggio
	 * @param messaggio Corpo str testuale
	 * @param data Data stampigliata locale
	 * <p><b>Precondizioni:</b> {@code messaggio != null && data != null}</p>
	 * <p><b>Postcondizioni:</b> Memorizzati due stream field pronti ad export.</p>
	 */
	public Notifica(String messaggio, LocalDate data) {
		this.messaggio = messaggio;
		this.data = data;
	}

	/** 
	 * @return Get content text
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public String getMessaggio() {
		return messaggio;
	}

	/** 
	 * @return Get date object
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public LocalDate getData() {
		return data;
	}

	@Override
	public String toString() {
		return "[" + ValidatoreData.format(data) + "] " + messaggio;
	}
}