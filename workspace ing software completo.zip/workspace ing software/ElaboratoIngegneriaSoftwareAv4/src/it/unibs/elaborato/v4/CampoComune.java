package it.unibs.elaborato.v4;

public class CampoComune extends Campo {
	public CampoComune(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
}
