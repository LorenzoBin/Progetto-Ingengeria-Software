package it.unibs.elaborato.v4;

public class CampoSpecifico extends Campo {
	public CampoSpecifico(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
}
