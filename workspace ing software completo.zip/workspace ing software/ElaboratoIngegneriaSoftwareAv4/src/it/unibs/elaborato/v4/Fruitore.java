package it.unibs.elaborato.v4;

import java.util.*;

/**
 * Gestisce i dati identificativi individuali di ciascun Fruitore e la sua cache di messaggi.
 * <p><b>Invariante di classe:</b> {@code username != null && !username.isBlank() && spazioPersonale != null}</p>
 */
public class Fruitore {
	private String username;
	private List<Notifica> spazioPersonale = new ArrayList<>();

	/**
	 * Crea il record account utente.
	 * @param username Codice utente
	 * <p><b>Precondizioni:</b> {@code username != null && !username.isBlank()}</p>
	 * <p><b>Postcondizioni:</b> Un oggetto istanziato col suo campo stringa settato e queue array messaggi pronta a riceverne.</p>
	 */
	public Fruitore(String username) {
		this.username = username;
	}

	/** 
	 * @return Identifier dell'umano 
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public String getUsername() {
		return username;
	}

	/**
	 * @return L'array volatile contenente comunicazioni amministrative e avvisi Iniziative
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public List<Notifica> getSpazioPersonale() {
		return spazioPersonale;
	}

	/**
	 * Append message a utente
	 * @param n Oggetto strutturato del promemoria/annullamento
	 * <p><b>Precondizioni:</b> {@code n != null}</p>
	 * <p><b>Postcondizioni:</b> Code.size() incrementato di 1 con notifica pendente pushata in calce.</p>
	 */
	public void aggiungiNotifica(Notifica n) {
		spazioPersonale.add(n);
	}

	/**
	 * Rimozione da casella di posta per volere dell'utente in front-end
	 * @param index posizione numero della lista.
	 * <p><b>Precondizioni:</b> {@code index >= 0}</p>
	 * <p><b>Postcondizioni:</b> Element rimossa if range inbounds of list.</p>
	 */
	public void rimuoviNotifica(int index) {
		if (index >= 0 && index < spazioPersonale.size())
			spazioPersonale.remove(index);
	}
}
