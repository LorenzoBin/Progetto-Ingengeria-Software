package it.unibs.elaborato.v4;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Contenitore logico persistente delle iniziative pubbliche o storicizzate.
 * <p><b>Invariante di classe:</b> {@code proposte != null}</p>
 */
public class Bacheca {
	private List<Proposta> proposte = new ArrayList<>();

	/**
	 * Append al calderone v4.
	 * @param p La proposta da includere.
	 * <p><b>Precondizioni:</b> {@code p != null}</p>
	 * <p><b>Postcondizioni:</b> Dimensioni array +1.</p>
	 */
	public void aggiungi(Proposta p) {
		proposte.add(p);
	}

	/**
	 * Ritorna l'archivio completo compreso confermate, annullate e concluse per storicizzazione e Configuratore.
	 * @return Arraylist di referenza per file export.
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public List<Proposta> getTutte() {
		return proposte;
	}

	/**
	 * Crea un proxy stream per l'utenza che nasconde lo storico (Concluse, Annullate)
	 * In v4 la bacheca mostra SOLO quelle strettamente "Aperte" per l'iscrizione.
	 * @return List di filtered results
	 * <p><b>Postcondizioni:</b> Ritorna una lista separata read-only che garantisce il filter match state.</p>
	 */
	public List<Proposta> getAperte() {
		return proposte.stream().filter(p -> p.getStatoAttuale().equals("Aperta")).collect(Collectors.toList());
	}

	/**
	 * Proxy ristretto alla label della categoria.
	 * @param nomeCategoria ID root group
	 * @return Sottoinsieme su Aperte targettato a string comparison case-insensitive.
	 * <p><b>Precondizioni:</b> {@code nomeCategoria != null}</p>
	 * <p><b>Postcondizioni:</b> Ritorna un filter di un filter.</p>
	 */
	public List<Proposta> filtraPerCategoria(String nomeCategoria) {
		return getAperte().stream().filter(p -> p.getCategoria().getNome().equalsIgnoreCase(nomeCategoria))
				.collect(Collectors.toList());
	}
}
