package it.unibs.elaborato.v4;

import java.time.LocalDate;

/**
 * Tracciabilità immutabile del cambio di stato subito da una proposta, vitale per la logistica.
 * <p><b>Invariante di classe:</b> {@code stato != null && data != null}</p>
 */
public class RecordStato {
	private String stato;
	private LocalDate data;

	/**
	 * @param stato Testo stato formalizzato
	 * @param data Date of translation
	 * <p><b>Precondizioni:</b> Parametri costruttore validi not-nulls.</p>
	 * <p><b>Postcondizioni:</b> Instanza cronologica snapshot prodotta pronta alla gettata.</p>
	 */
	public RecordStato(String stato, LocalDate data) {
		this.stato = stato;
		this.data = data;
	}

	/** 
	 * @return Etichetta verbale fase attraversata (es. Confermata, Annullata). 
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public String getStato() {
		return stato;
	}

	/** 
	 * @return Giorno locale
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public LocalDate getData() {
		return data;
	}

	@Override
	public String toString() {
		return stato + " (" + ValidatoreData.format(data) + ")";
	}
}
