package it.unibs.elaborato.v2;

import java.io.*;
import java.util.*;

/**
 * Gestisce l'accesso al sistema, la verifica delle credenziali e
 * il salvataggio/caricamento degli utenti (Configuratori).
 * 
 * <p><b>Invariante di classe:</b> {@code utentiRegistrati != null}</p>
 */
public class SessioneLogin {
	
	private final Map<String, String> utentiRegistrati;
	private static final String ADMIN_MASTER = "admin";

	/**
	 * Crea un'istanza della mappa per l'autenticazione.
	 * 
	 * <p><b>Postcondizioni:</b> Istanza pronta con archivio utenti vuoto.</p>
	 */
	public SessioneLogin() {
		this.utentiRegistrati = new HashMap<>();
	}

	/**
	 * Verifica se le credenziali inserite corrispondono a quelle
	 * dell'amministratore master temporaneo per la creazione di account.
	 * 
	 * @param username Il nome utente loggato.
	 * @param password La password in input.
	 * @return true se corrispondono ai parametri bypass.
	 * 
	 * <p><b>Precondizioni:</b> {@code username != null && password != null}</p>
	 * <p><b>Postcondizioni:</b> Non vengono modificati record interni.</p>
	 */
	public boolean isMasterAdmin(String username, String password) {
		return ADMIN_MASTER.equals(username) && ADMIN_MASTER.equals(password);
	}

	/**
	 * Restituisce true se l'utente è registrato e la password è corretta.
	 * 
	 * @param username username.
	 * @param password assword.
	 * @return Il risultato logico dell'autenticazione.
	 * 
	 * <p><b>Precondizioni:</b> {@code username != null && password != null}</p>
	 */
	public boolean autentica(String username, String password) {
		return utentiRegistrati.containsKey(username) && utentiRegistrati.get(username).equals(password);
	}

	/**
	 * Salva un nuovo configuratore.
	 * 
	 * @param username Nome.
	 * @param password Password del nome.
	 * @return false se lo username è già registrato (vietato duplicato), true in caso di successo.
	 * 
	 * <p><b>Precondizioni:</b> {@code username != null && password != null && !username.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Se l'inserimento ha successo, l'utente viene aggiunto alla mappa.</p>
	 */
	public boolean registraNuovo(String username, String password) {
		if (esisteGia(username)) {
			return false;
		}
		
		utentiRegistrati.put(username, password);
		return true;
	}

	/**
	 * Controlla che uno username sia in utilizzo o se sia vietato (admin).
	 * 
	 * @param username La mail di login o nome utente.
	 * @return Un test fallito se già occupato o prenotato.
	 * 
	 * <p><b>Precondizioni:</b> {@code username != null}</p>
	 */
	public boolean esisteGia(String username) {
		return utentiRegistrati.containsKey(username) || ADMIN_MASTER.equalsIgnoreCase(username);
	}

	/**
	 * Salva in modo persistente le credenziali nel file di testo specificato.
	 * 
	 * @param filePath Path del file txt destinazione.
	 * @throws IOException in caso di problema in scrittura.
	 * 
	 * <p><b>Precondizioni:</b> {@code filePath != null && !filePath.isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Vengono persistite le credenziali sul file system nella root fornita.</p>
	 */
	public void salva(String filePath) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
			for (Map.Entry<String, String> entry : utentiRegistrati.entrySet()) {
				writer.println(entry.getKey() + ";" + entry.getValue());
			}
		}
	}

	/**
	 * Carica in memoria gli account registrati dal file di testo.
	 * 
	 * @param filePath Path del file txt in cui ci sono gli auth.
	 * @throws IOException in caso non via sia caricamento.
	 * 
	 * <p><b>Precondizioni:</b> {@code filePath != null && !filePath.isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Popola {@code utentiRegistrati} se il file esiste format atteso senza cancellare i pre-esistenti.</p>
	 */
	public void carica(String filePath) throws IOException {
		File fileCredenziali = new File(filePath);
		
		if (!fileCredenziali.exists()) {
			return;
		}
		
		try (BufferedReader reader = new BufferedReader(new FileReader(fileCredenziali))) {
			String lineaLetta;
			while ((lineaLetta = reader.readLine()) != null) {
				String[] parti = lineaLetta.split(";");
				if (parti.length >= 2) {
					String username = parti[0];
					String password = parti[1];
					utentiRegistrati.put(username, password);
				}
			}
		}
	}
}
