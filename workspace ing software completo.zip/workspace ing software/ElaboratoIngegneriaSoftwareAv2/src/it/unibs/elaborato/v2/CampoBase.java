package it.unibs.elaborato.v2;

/**
 * Rappresenta un Campo Base definito a livello di sistema.
 * <p>
 * I Campi Base sono condivisi intrinsecamente da tutte le iniziative, a prescindere 
 * dalla categoria di appartenenza (es. "Titolo", "Numero partecipanti"). 
 * Sono strutturalmente <b>immutabili</b> nel loro stato di obbligatorietà, 
 * in quanto essenziali per il funzionamento minimo dell'applicazione.
 * </p>
 * 
 * <p><b>Invariante di classe:</b> {@code isObbligatorio() == true}</p>
 */
public class CampoBase extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Base. 
	 * Di default, viene forzato l'attributo obbligatorio a {@code true}.
	 * 
	 * @param nome Il nome univoco e descrittivo del Campo Base.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> L'oggetto viene creato con il flag di obbligatorio costantemente a {@code true}.</p>
	 */
	public CampoBase(String nome) {
		super(nome, true);
	}

	/**
	 * Impedisce la modifica dell'obbligatorietà di un Campo Base.
	 * Essendo essenziali al sistema, questi campi rimangono sempre obbligatori.
	 * 
	 * @param obbligatorio Il nuovo stato (ignorato).
	 * @throws UnsupportedOperationException Sempre, per proteggere l'immutabilità logica del campo.
	 * 
	 * <p><b>Precondizioni:</b> Nessuna.</p>
	 * <p><b>Postcondizioni:</b> Solleva sempre {@link UnsupportedOperationException}. Non muta lo stato.</p>
	 */
	@Override
	public void setObbligatorio(boolean obbligatorio) {
		throw new UnsupportedOperationException("Errore: I campi base sono immutabili e sempre obbligatori.");
	}
}
