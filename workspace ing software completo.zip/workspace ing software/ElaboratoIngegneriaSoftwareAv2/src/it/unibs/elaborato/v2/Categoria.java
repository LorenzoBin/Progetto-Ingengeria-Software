package it.unibs.elaborato.v2;

import java.util.ArrayList;
import java.util.List;

/**
 * Rappresenta una Categoria che accomuna una varietà di iniziative.
 * <p>
 * Ogni categoria viene definita dal configuratore e ha lo scopo di raggruppare iniziative
 * affini per tematica (es. "Sport", "Cultura", "Gite"). Contiene inoltre un registro
 * di {@link CampoSpecifico} dedicati unicamente a raccogliere caratteristiche dettagliate 
 * per quella singola cerchia di eventi.
 * </p>
 * 
 * <p><b>Invariante di classe:</b> {@code nome != null && !nome.trim().isEmpty() && campiSpecifici != null}</p>
 */
public class Categoria {
	
	private final String nome;
	private final List<CampoSpecifico> campiSpecifici;

	/**
	 * Costruttore per creare una nuova Categoria di base.
	 * 
	 * @param nome Il nome univoco identificativo della categoria.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Nome applicato e lista interna di campi costruita vuota.</p>
	 */
	public Categoria(String nome) {
		this.nome = nome;
		this.campiSpecifici = new ArrayList<>();
	}

	/**
	 * Restituisce il nome della categoria.
	 * 
	 * @return Il nome esteso della categoria.
	 * 
	 * <p><b>Postcondizioni:</b> {@code return != null && !return.trim().isEmpty()}</p>
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Restituisce l'elenco dei campi specifici registrati della categoria.
	 * 
	 * @return Una lista di {@link CampoSpecifico}.
	 * 
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public List<CampoSpecifico> getCampiSpecifici() {
		return campiSpecifici;
	}

	/**
	 * Associa un nuovo campo specifico a questa categoria.
	 * 
	 * @param campoSpecifico Il {@link CampoSpecifico} da aggiungere all'archivio della categoria.
	 * 
	 * <p><b>Precondizioni:</b> {@code campoSpecifico != null}</p>
	 * <p><b>Postcondizioni:</b> Il campo è stato aggiunto alla lista {@code campiSpecifici}.</p>
	 */
	public void aggiungiCampoSpecifico(CampoSpecifico campoSpecifico) {
		this.campiSpecifici.add(campoSpecifico);
	}

	/**
	 * Stampa a console in modo formattato e visivamente strutturato tutte le 
	 * configurazioni pertinenti a questa Categoria. Include il recap e la somma complessiva 
	 * dei vari domini dei campi: Base, Comuni e Specifici.
	 * 
	 * @param campiBase   La lista dei campi di base in vigore sul sistema.
	 * @param campiComuni La lista dei campi condivisibili globalmente in vigore.
	 * 
	 * <p><b>Precondizioni:</b> {@code campiBase != null && campiComuni != null}</p>
	 * <p><b>Postcondizioni:</b> Stato stampato formattato standard output.</p>
	 */
	public void visualizza(List<CampoBase> campiBase, List<CampoComune> campiComuni) {
		System.out.printf("%n=== CATEGORIA: %s ===%n", nome.toUpperCase());
		System.out.println(" -> Campi Base:");
		campiBase.forEach(campo -> System.out.println("    - " + campo));
		
		System.out.println(" -> Campi Comuni:");
		campiComuni.forEach(campo -> System.out.println("    - " + campo));
		
		System.out.println(" -> Campi Specifici:");
		campiSpecifici.forEach(campo -> System.out.println("    - " + campo));
		System.out.println("==========================\n");
	}
}
