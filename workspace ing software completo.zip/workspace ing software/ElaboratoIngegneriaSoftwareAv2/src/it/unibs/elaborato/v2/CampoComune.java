package it.unibs.elaborato.v2;

/**
 * Rappresenta un Campo Comune nel sistema delle iniziative.
 * <p>
 * I Campi Comuni sono decisi dal configuratore in fase di setup e si applicano trasversalmente
 * a tutte le categorie, sebbene la loro compilazione possa essere sia facoltativa che obbligatoria a scelta.
 * </p>
 * 
 * <p><b>Invariante di classe:</b> Rispetta gli invarianti della superclasse {@link Campo}.</p>
 */
public class CampoComune extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Comune personalizzato.
	 * 
	 * @param nome         Il nome descrittivo del campo comune.
	 * @param obbligatorio Lo stato di obbligatorietà del campo, configurabile liberamente.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Campo comune creato.</p>
	 */
	public CampoComune(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
}
