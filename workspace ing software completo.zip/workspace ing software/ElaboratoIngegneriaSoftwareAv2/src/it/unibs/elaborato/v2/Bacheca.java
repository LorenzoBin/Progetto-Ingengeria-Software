package it.unibs.elaborato.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Gestisce l'archivio delle Proposte pubblicate (Aperte).
 * <p><b>Invariante di classe:</b> {@code proposteAperte != null}</p>
 */
public class Bacheca {
    private List<Proposta> proposteAperte = new ArrayList<>();

    /**
     * Aggiunge una proposta aperta alla bacheca.
     * @param p La proposta da includere.
     * <p><b>Precondizioni:</b> {@code p != null}</p>
     * <p><b>Postcondizioni:</b> La proposta si trova nella collezione.</p>
     */
    public void aggiungi(Proposta p) {
        proposteAperte.add(p);
    }

    /**
     * @return L'elenco integrale delle proposte in bacheca.
     * <p><b>Postcondizioni:</b> {@code return != null}</p>
     */
    public List<Proposta> getTutte() {
        return proposteAperte;
    }

    /**
     * Estrae le proposte legate a una categoria specifica.
     * @param nomeCategoria Stringa target corrispondente al nome categoria.
     * @return Una sublist delle sole proposte aderenti al filtro.
     * <p><b>Precondizioni:</b> {@code nomeCategoria != null}</p>
     * <p><b>Postcondizioni:</b> Ognuna delle proposte tornate ha la categoria indicata.</p>
     */
    public List<Proposta> filtraPerCategoria(String nomeCategoria) {
        return proposteAperte.stream()
                .filter(p -> p.getCategoria().getNome().equalsIgnoreCase(nomeCategoria))
                .collect(Collectors.toList());
    }

    /**
     * Elimina tutte le proposte svuotando la bacheca.
     * <p><b>Postcondizioni:</b> {@code proposteAperte.isEmpty() == true}</p>
     */
    public void svuota() {
        proposteAperte.clear();
    }
}