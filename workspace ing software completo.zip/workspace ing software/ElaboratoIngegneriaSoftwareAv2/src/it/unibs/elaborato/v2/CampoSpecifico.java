package it.unibs.elaborato.v2;

/**
 * Rappresenta un Campo Specifico assegnato a una particolare Categoria.
 * <p>
 * A differenza di campi base o comuni che valgono per tutto il sistema, i campi specifici 
 * sono peculiarità che permettono di acquisire dettagli necessari limitatamente 
 * a una tipologia di iniziativa (ad esempio: "Squadre partecipanti" per un torneo di calcio).
 * </p>
 * 
 * <p><b>Invariante di classe:</b> Eredita l'invariante da {@link Campo}.</p>
 */
public class CampoSpecifico extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Specifico per una categoria.
	 * 
	 * @param nome         Il nome descrittivo del campo ristretto.
	 * @param obbligatorio {@code true} se la sua compilazione per questa categoria è obbligatoria.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Campo specifico generato e coerente agli attributi d'ingresso.</p>
	 */
	public CampoSpecifico(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
}
