package it.unibs.elaborato.v2;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Gestisce i dati di un'istanza di evento (iniziativa).
 * <p><b>Invariante di classe:</b> {@code categoria != null && valoriInseriti != null && stato != null}</p>
 */
public class Proposta {
    private final Categoria categoria;
    private final Map<String, String> valoriInseriti = new HashMap<>();
    private String stato; 
    private LocalDate dataPubblicazione;

    /**
     * Crea un'istanza legata obbligatoriamente a una Categoria strutturata.
     * 
     * @param categoria La Categoria base
     * <p><b>Precondizioni:</b> {@code categoria != null}</p>
     * <p><b>Postcondizioni:</b> Proposta creata in stato "In compilazione" con HashMap stringhe vuota pronta all'uso.</p>
     */
    public Proposta(Categoria categoria) {
        this.categoria = categoria;
        this.stato = "In compilazione";
    }

    /**
     * Aggiunge o sovrascrive un valore dinamico legato a uno dei campi della categoria.
     * 
     * @param nomeCampo nome stringa identificativo
     * @param valore stringa data testuale associata
     * <p><b>Precondizioni:</b> {@code nomeCampo != null && !nomeCampo.isBlank() && valore != null}</p>
     * <p><b>Postcondizioni:</b> Il valore è correttamente registrato per la chiave di quel campo.</p>
     */
    public void inserisciValore(String nomeCampo, String valore) {
        valoriInseriti.put(nomeCampo, valore);
    }

    /**
     * Estrae testualmente il dato configurato dal momento della compilazione bozza.
     * 
     * @param nomeCampo nome stringa identificativo (identifier string)
     * @return IL contenuto inserito dall'utente finale
     * <p><b>Precondizioni:</b> {@code nomeCampo != null}</p>
     * <p><b>Postcondizioni:</b> Ritorna il testo in mappa se presente (anche vuoto) altrimenti Null.</p>
     */
    public String getValore(String nomeCampo) {
        return valoriInseriti.get(nomeCampo);
    }

    /**
     * Espone la condizione astratta della bozza.
     * 
     * @return Lo stato logico corrente (es. Valida, Aperta, In compilazione)
     * <p><b>Postcondizioni:</b> {@code return != null}</p>
     */
    public String getStato() { return stato; }
    
    /** 
     * Modifica attivamente il permesso di archiviazione o vista al pubblico della riga in bacheca.
     * 
     * @param stato Nuovo stato "Valida" o "Aperta" 
     * <p><b>Precondizioni:</b> {@code stato != null && !stato.isBlank()}</p>
     * <p><b>Postcondizioni:</b> La proposta ora è segnata col nuovo descrittore testuale del database.</p>
     */
    public void setStato(String stato) { this.stato = stato; }
    
    /** 
     * Imposta il momento esatto in cui ha raggiunto la visibilità all'utenza.
     * 
     * @param data L'istanza formale del momento temporale locale della macchina.
     * <p><b>Precondizioni:</b> {@code data != null}</p>
     * <p><b>Postcondizioni:</b> Aggiorna la variabile dataPubblicazione della bozza.</p>
     */
    public void setDataPubblicazione(LocalDate data) { this.dataPubblicazione = data; }
    
    /** 
     * @return La struttura algebrica che identifica i metadati comuni
     * <p><b>Postcondizioni:</b> {@code return != null}</p>
     */
    public Categoria getCategoria() { return categoria; }

    /**
     * Codifica l'oggetto per formattarlo su file system bypassando la complessa astrazione java.
     * 
     * @return Formato stringa serializzabile di valori chiave/valore concatenati.
     * <p><b>Postcondizioni:</b> Testo delimitato da pipe `|` e duepunti `:` in format archive CSV-safe.</p>
     */
    public String esportaPerArchivio() {
        StringBuilder sb = new StringBuilder();
        sb.append(categoria.getNome()).append("|")
          .append(dataPubblicazione).append("|")
          .append(stato);
        for (Map.Entry<String, String> entry : valoriInseriti.entrySet()) {
            sb.append("|").append(entry.getKey()).append(":").append(entry.getValue());
        }
        return sb.toString();
    }

    @Override
    public String toString() {
        return String.format("\n[PROPOSTA %s] Categoria: %s\nPubblicata il: %s\nDati: %s", 
                stato.toUpperCase(), categoria.getNome(), ValidatoreData.format(dataPubblicazione), valoriInseriti);
    }
}