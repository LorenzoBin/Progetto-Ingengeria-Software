package it.unibs.elaborato.v5;

public class CampoSpecifico extends Campo {
	public CampoSpecifico(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
}
