package it.unibs.elaborato.v5;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoUnit;

/**
 * Utility per gestire e validare le stringhe e stringhe in date e per imporre i 
 * vincoli logico-temporali della Versione 3.
 * 
 * <p><b>Invariante di classe:</b> Essendo una classe utilitaria con metodi statici, 
 * lo stato interno è inesistente e puramente immutabile.</p>
 */
public class ValidatoreData {
    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/uuuu")
            .withResolverStyle(ResolverStyle.STRICT);

    /**
     * Intercetta una stringa e la decodifica in caso il formato sia DD/MM/YYYY.
     * 
     * @param dataStr Formattata raw utente
     * @return L'oggetto parsato. Se fallisce o non supportato torna Null. 
     * 
     * <p><b>Precondizioni:</b> Nessuna restrizione logica in input bypassata in trycatch.</p>
     * <p><b>Postcondizioni:</b> Restituisce LocalDate valido o Null.</p>
     */
    public static LocalDate parse(String dataStr) {
        try {
            if (dataStr == null || dataStr.trim().isEmpty()) return null;
            return LocalDate.parse(dataStr.trim(), FORMATTER);
        } catch (DateTimeParseException e) {
            return null;
        }
    }

    /**
     * Verifica la strict posteriorità di una data rispetto all'orario attuale.
     * 
     * @param termine Data inserita e parsata.
     * @return boolean dell'esito.
     * 
     * <p><b>Precondizioni:</b> Nessuna, accetta anche Null ritornando false in quel caso.</p>
     * <p><b>Postcondizioni:</b> {@code return == termine != null && termine.isAfter(LocalDate.now())}</p>
     */
    public static boolean isTermineValido(LocalDate termine) {
        LocalDate oggi = LocalDate.now();
        return termine != null && termine.isAfter(oggi);
    }

    /**
     * Calcola la distanza aritmetica in ChronoDays e ne approva il differenziale >= 2.
     * 
     * @param termine Ultima data d'iscrizione consentita
     * @param inizioEvento La giornata per l'iniziativa
     * @return test passato logicamente se distanza d'assunzione tollerata dal sistema
     * 
     * <p><b>Precondizioni:</b> Entrambe le entità passate non determinatamente nulle.</p>
     * <p><b>Postcondizioni:</b> Ritorna {@code true} strettamente se Chrono difference >= 2.</p>
     */
    public static boolean isDistanzaMinimaRispettata(LocalDate termine, LocalDate inizioEvento) {
        if (termine == null || inizioEvento == null) return false;
        long giorni = ChronoUnit.DAYS.between(termine, inizioEvento);
        return giorni >= 2; // Almeno due giorni di differenza
    }

    /**
     * Offusca i dati per l'esportazione verso output stream / file raw txt.
     * @param data Oggetto java
     * @return Ritorna la formattazione stringa leggibile dell'istanza o N/A se nullo
     * <p><b>Postcondizioni:</b> Scrittura senza eccezioni nullpointer.</p>
     */
    public static String format(LocalDate data) {
        return (data == null) ? "N/A" : data.format(FORMATTER);
    }
}
