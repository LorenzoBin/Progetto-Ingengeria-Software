package it.unibs.elaborato.v5;

import java.time.LocalDate;
import java.util.*;

/**
 * Gestisce i dati di un'istanza di evento (iniziativa) e il suo incartamento di mutamenti nel tempo (Storia).
 * <p><b>Invariante di classe:</b> {@code categoria != null && valoriInseriti != null && storicoStati != null && iscritti != null}</p>
 */
public class Proposta {
	private final Categoria categoria;
	private final Map<String, String> valoriInseriti = new HashMap<>();
	private List<RecordStato> storicoStati = new ArrayList<>();
	private List<String> iscritti = new ArrayList<>(); // Lista username fruitori aderenti

	/**
	 * Inizializza con binding categoria.
	 * @param categoria La Categoria radice.
	 * <p><b>Precondizioni:</b> {@code categoria != null}</p>
	 * <p><b>Postcondizioni:</b> Proposta pronta senza stati.</p>
	 */
	public Proposta(Categoria categoria) {
		this.categoria = categoria;
	}

	/**
	 * Append mappa key value custom.
	 * @param nomeCampo Key 
	 * @param valore Testo Input
	 * <p><b>Precondizioni:</b> {@code nomeCampo != null && valore != null}</p>
	 * <p><b>Postcondizioni:</b> Inserito correttamente.</p>
	 */
	public void inserisciValore(String nomeCampo, String valore) {
		valoriInseriti.put(nomeCampo, valore);
	}

	/**
	 * Retrive map value
	 * @param nomeCampo id locale
	 * @return get string
	 * <p><b>Postcondizioni:</b> Ritorna null se not found altrimenti ok.</p>
	 */
	public String getValore(String nomeCampo) {
		return valoriInseriti.get(nomeCampo);
	}

	/** 
	 * @return Categoria
	 * <p><b>Postcondizioni:</b> Not null e referenza ok.</p>
	 */
	public Categoria getCategoria() {
		return categoria;
	}

	/** 
	 * @return User list attivamente aderenti 
	 * <p><b>Postcondizioni:</b> Non sarà mai nullo.</p>
	 */
	public List<String> getIscritti() {
		return iscritti;
	}

	/**
	 * Legge dinamicamente il campo e casta se possibile, altrimenti 0 limite rotto.
	 * @return Limite massimo iscrizioni concesse.
	 * <p><b>Postcondizioni:</b> Operatività garantita anche se campo testuale malformato (catch integer 0 default).</p>
	 */
	public int getMaxPartecipanti() {
		try {
			return Integer.parseInt(valoriInseriti.getOrDefault("Numero di partecipanti", "0"));
		} catch (NumberFormatException e) {
			return 0;
		}
	}

	/**
	 * Recupera l'ultimo dei trigger di stato se disponibile, fallback "In compilazione" logico.
	 * @return Etichetta verbale fase attraversata (es. Confermata, Aperta).
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public String getStatoAttuale() {
		if (storicoStati.isEmpty())
			return "In compilazione";
		return storicoStati.get(storicoStati.size() - 1).getStato();
	}

	/**
	 * Aggiorna il percorso di transizione temporale pushando il nuovo cambio di stato nel Log.
	 * @param nuovoStato Target da incapsulare ('Confermata', 'Annullata', 'Aperta', 'Conclusa')
	 * <p><b>Precondizioni:</b> {@code nuovoStato != null}</p>
	 * <p><b>Postcondizioni:</b> L'array storico si accresce del log firmato in LocalDate locale temporale della macchina ospite.</p> // Turbo-All
	 */
	public void setStato(String nuovoStato) {
		storicoStati.add(new RecordStato(nuovoStato, LocalDate.now()));
	}

	/** @return Get array stati per visualizzazione <p><b>Postcondizioni:</b> Not null.</p> */
	public List<RecordStato> getStoricoStati() {
		return storicoStati;
	}

	/**
	 * Controlla che le procedure di validazione incrociate v4 siano rispettate prima dell'attacco.
	 * @param username Richiedente
	 * @return Se l'utente puo' inserirsi secondo i canoni della normativa del problema
	 * <p><b>Precondizioni:</b> {@code username != null && !username.isBlank()}</p>
	 * <p><b>Postcondizioni:</b> Falso se c'è cap raggiunto, duplicato o Proposta chiusa altrimenti true allow pass.</p>
	 */
	public boolean puoIscriversi(String username) {
		if (!getStatoAttuale().equals("Aperta"))
			return false;
		if (iscritti.contains(username))
			return false;
		if (iscritti.size() >= getMaxPartecipanti()) // Vincolo "Eguaglia il numero partecipanti previsto"
			return false;
		return true;
	}

	/**
	 * Processa l'ingresso accodando se passa la validazione
	 * @param username fruitore code ID
	 * @return Se successo avvenuto
	 * <p><b>Precondizioni:</b> {@code username != null}</p>
	 * <p><b>Postcondizioni:</b> lista iscritti cresce di 1 unita se confermato boolean response vero.</p> // Turbo-All
	 */
	public boolean iscrivi(String username) {
		if (puoIscriversi(username)) {
			iscritti.add(username);
			return true;
		}
		return false;
	}

	/**
	 * Verifica la plausibilità temporale per la disiscrizione volontaria.
	 * @param username Richiedente
	 * @return Se l'utente puo' sganciarsi secondo la scadenza (solo stati 'Aperta')
	 * <p><b>Precondizioni:</b> {@code username != null && !username.isBlank()}</p>
	 */
	public boolean puoDisdire(String username) {
		return getStatoAttuale().equals("Aperta") && iscritti.contains(username);
	}

	/**
	 * Disconnette un aderente dalla lista attivi
	 * @param username fruitore code ID
	 * @return Se successo avvenuto
	 * <p><b>Precondizioni:</b> {@code username != null}</p>
	 * <p><b>Postcondizioni:</b> iscritti rimpicciolita di 1 elemento.</p>
	 */
	public boolean disdici(String username) {
		if (puoDisdire(username)) {
			iscritti.remove(username);
			return true;
		}
		return false;
	}

	/**
	 * Controlla che le procedure di forza maggiore per V4 siano valide (Ritiro entro -1 giorno).
	 * @return Se la proposta e' candidata al colpo di grazia.
	 * <p><b>Postcondizioni:</b> Approvato strettamente se giorno corrente precede "Data" dell'evento.</p>
	 */
	public boolean puoEssereRitirata() {
		String stato = getStatoAttuale();
		if (!stato.equals("Aperta") && !stato.equals("Confermata")) return false;
		
		LocalDate dataEvento = ValidatoreData.parse(getValore("Data"));
		if (dataEvento == null) return false;
		
		return LocalDate.now().isBefore(dataEvento);
	}

	/**
	 * V4: Export corretto e blindato! Separatore primario Array: ##, separatore chiave/valore: =, sep sublist: ~.
	 * @return Stringa raw per database plain text.
	 * <p><b>Postcondizioni:</b> Formato incapsulato impossibile da rompere coi default di librerie standard.</p>
	 */
	public String esportaPerArchivio() {
		StringBuilder sb = new StringBuilder(categoria.getNome() + "##");
		for (Map.Entry<String, String> e : valoriInseriti.entrySet()) {
			sb.append(e.getKey()).append("=").append(e.getValue()).append("~");
		}
		sb.append("##");
		for (RecordStato rs : storicoStati) {
			sb.append(rs.getStato()).append("=").append(ValidatoreData.format(rs.getData())).append("~");
		}
		sb.append("##");
		if (!iscritti.isEmpty()) {
			sb.append(String.join("~", iscritti));
		}
		return sb.toString();
	}

	@Override
	public String toString() {
		String base = String.format("\n[%s] Categoria: %s | Titolo: %s", getStatoAttuale().toUpperCase(),
				categoria.getNome(), getValore("Titolo"));
		if (getStatoAttuale().equals("Aperta") || getStatoAttuale().equals("Confermata")) {
			base += String.format("\n    Iscritti: %d/%d | Scadenza: %s | Evento: %s", iscritti.size(),
					getMaxPartecipanti(), getValore("Termine ultimo di iscrizione"), getValore("Data"));
		}
		return base;
	}
}
