package it.unibs.elaborato.v5;

import java.io.*;
import java.util.*;

/**
 * Motore di accesso per ramificazione multipla dell'applicativo iterazione 3.
 * <p><b>Invariante di classe:</b> {@code configuratori != null && fruitori != null}</p>
 */
public class SessioneLogin {
	private Map<String, String> configuratori = new HashMap<>();
	private Map<String, String> fruitori = new HashMap<>();
	private static final String ADMIN_MASTER = "admin";

	/**
	 * Check login the top-tier account
	 * @param u Usr
	 * @param p Psw
	 * @return Se u e p sono combacianti alle costanti hardcoded del root d'impianto.
	 * <p><b>Precondizioni:</b> {@code u != null && p != null}</p>
	 */
	public boolean isMasterAdmin(String u, String p) {
		return ADMIN_MASTER.equals(u) && ADMIN_MASTER.equals(p);
	}

	/**
	 * Check credenziali trasversale ad ambo i branch d'utenza 
	 * @param u id pass
	 * @param p id lock
	 * @return Testo enum-like di flag ruolo se corretto ("CONFIGURATORE" o "FRUITORE"), altrimenti Null per login negato
	 * <p><b>Precondizioni:</b> {@code u != null && p != null}</p>
	 * <p><b>Postcondizioni:</b> Match effettuato e return convalidato.</p>
	 */
	public String autentica(String u, String p) {
		if (configuratori.containsKey(u) && configuratori.get(u).equals(p))
			return "CONFIGURATORE";
		if (fruitori.containsKey(u) && fruitori.get(u).equals(p))
			return "FRUITORE";
		return null;
	}

	/**
	 * @param u Nome identificativo
	 * @return Vero se lo username è nel pool globale in uso sia Fruitori che Configuratori.
	 * <p><b>Precondizioni:</b> {@code u != null && !u.isBlank()}</p>
	 */
	public boolean esisteGia(String u) {
		return configuratori.containsKey(u) || fruitori.containsKey(u) || ADMIN_MASTER.equalsIgnoreCase(u);
	}

	/**
	 * Iscrizione livello 1 admin
	 * @param u nome
	 * @param p psw
	 * @return se creata con successo
	 * <p><b>Precondizioni:</b> username sgombro e non nullo.</p>
	 * <p><b>Postcondizioni:</b> Modificata map configuratori RAM se esito affermativo.</p>
	 */
	public boolean registraConfiguratore(String u, String p) {
		if (esisteGia(u))
			return false;
		configuratori.put(u, p);
		return true;
	}

	/**
	 * Iscrizione livello 2 guest
	 * @param u usr
	 * @param p psw
	 * @return se creata con successo
	 * <p><b>Precondizioni:</b> username valid non nullo</p>
	 * <p><b>Postcondizioni:</b> Modificata map Fruitori locale.</p>
	 */
	public boolean registraFruitore(String u, String p) {
		if (esisteGia(u))
			return false;
		fruitori.put(u, p);
		return true;
	}

	/**
	 * Esporta le chiavi per sicurezza offline in plain text CSV mode v4.
	 * @param path dest output
	 * @throws IOException 
	 * <p><b>Precondizioni:</b> {@code path != null}</p>
	 * <p><b>Postcondizioni:</b> File fisico rimpiazzato con due header di sezione.</p>
	 */
	public void salva(String path) throws IOException {
		try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
			pw.println("CONFIGURATORI");
			for (Map.Entry<String, String> e : configuratori.entrySet())
				pw.println(e.getKey() + ";" + e.getValue());
			pw.println("FRUITORI");
			for (Map.Entry<String, String> e : fruitori.entrySet())
				pw.println(e.getKey() + ";" + e.getValue());
		}
	}

	/**
	 * Rilegge credenziali riapplicando hashmap separate.
	 * @param path dest target filesystem res
	 * @throws IOException in failed seek read
	 * <p><b>Precondizioni:</b> {@code path != null}</p>
	 * <p><b>Postcondizioni:</b> Se file pre-esiste, login maps rimpolpate di configuratori/fruitori.</p>
	 */
	public void carica(String path) throws IOException {
		File f = new File(path);
		if (!f.exists())
			return;
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String l;
			String sez = "CONFIGURATORI"; // Default essenziale per vecchi file della V2
			while ((l = br.readLine()) != null) {
				if (l.equals("CONFIGURATORI") || l.equals("FRUITORI")) {
					sez = l;
					continue;
				}
				String[] p = l.split(";");
				if (p.length >= 2) {
					if (sez.equals("CONFIGURATORI"))
						configuratori.put(p[0], p[1]);
					else
						fruitori.put(p[0], p[1]);
				}
			}
		}
	}
}
