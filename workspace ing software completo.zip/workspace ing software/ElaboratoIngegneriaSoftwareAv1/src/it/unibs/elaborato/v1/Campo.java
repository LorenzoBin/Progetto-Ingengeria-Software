package it.unibs.elaborato.v1;

/**
 * Rappresenta la struttura astratta di base per un campo informativo.
 * Un campo rappresenta una singola informazione (es. "Luogo", "Data", "Costo") 
 * che caratterizza un'iniziativa o una categoria.
 * 
 * <p><b>Invariante di classe:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
 */
public abstract class Campo {
	
	private final String nome;
	private boolean obbligatorio;

	/**
	 * Costruisce una nuova istanza di un Campo.
	 * 
	 * @param nome         Il nome descrittivo del campo (es. "Quota di iscrizione").
	 * @param obbligatorio {@code true} se la compilazione del campo è indispensabile, {@code false} se facoltativa.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Il campo è istanziato, {@code getNome().equals(nome)} e {@code isObbligatorio() == obbligatorio}</p>
	 */
	public Campo(String nome, boolean obbligatorio) {
		this.nome = nome;
		this.obbligatorio = obbligatorio;
	}

	/**
	 * Restituisce il nome descrittivo del campo.
	 * 
	 * @return Una stringa contenente il nome del campo.
	 * 
	 * <p><b>Postcondizioni:</b> {@code return != null && !return.trim().isEmpty()}</p>
	 */
	public String getNome() {
		return nome;
	}

	/**
	 * Verifica se il campo è obbligatorio.
	 * 
	 * @return {@code true} se il campo deve essere compilato obbligatoriamente, {@code false} altrimenti.
	 */
	public boolean isObbligatorio() {
		return obbligatorio;
	}

	/**
	 * Imposta l'obbligatorietà del campo.
	 * 
	 * @param obbligatorio Il nuovo stato di obbligatorietà per il campo.
	 * 
	 * <p><b>Postcondizioni:</b> {@code isObbligatorio() == obbligatorio}</p>
	 */
	public void setObbligatorio(boolean obbligatorio) {
		this.obbligatorio = obbligatorio;
	}

	/**
	 * Restituisce una rappresentazione testuale del campo, comprensiva 
	 * del nome e del suo stato di obbligatorietà.
	 * 
	 * @return Una stringa formattata rappresentante lo stato dell'oggetto.
	 * 
	 * <p><b>Postcondizioni:</b> {@code return != null && return.contains(nome)}</p>
	 */
	@Override
	public String toString() {
		String statoObbligatorieta = obbligatorio ? " [Obbligatorio]" : " [Facoltativo]";
		return nome + statoObbligatorieta;
	}
}