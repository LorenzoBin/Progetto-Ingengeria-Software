package it.unibs.elaborato.v1;

import java.io.*;
import java.util.*;

/**
 * Gestisce la logica di business principale per le categorie e i campi.
 * <p>
 * Detiene le liste dei campi base, comuni e la mappa delle categorie scelte.
 * Si occupa inoltre della persistenza di queste configurazioni tramite salvataggio
 * e caricamento su file system, centralizzando la manipolazione dei dati in tempo reale.
 * </p>
 * 
 * <p><b>Invariante di classe:</b> {@code campiBase != null && campiComuni != null && categorie != null}</p>
 */
public class Configuratore {
	
	private final List<CampoBase> campiBase;
	private final List<CampoComune> campiComuni;
	private final Map<String, Categoria> categorie;

	/**
	 * Inizializza un nuovo sistema di archiviazione dati vuoto.
	 * 
	 * <p><b>Postcondizioni:</b> Le collezioni interne sono istanziate vuote salvaguardando l'invariante di classe.</p>
	 */
	public Configuratore() {
		this.campiBase = new ArrayList<>();
		this.campiComuni = new ArrayList<>();
		this.categorie = new HashMap<>();
	}


	/**
	 * Carica i campi base da file. Se il file non esiste o è vuoto, 
	 * forza l'inserimento immediato dei campi iniziali e li salva su disco.
	 * 
	 * @param filePath Il percorso in cui risiede il file testuale campi_base.txt.
	 * @throws IOException In caso di malfunzionamenti o divieti d'accesso in scrittura/lettura.
	 * 
	 * <p><b>Precondizioni:</b> {@code filePath != null && !filePath.isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> {@code !campiBase.isEmpty()}</p>
	 */
	public void caricaOInizializzaCampiBase(String filePath) throws IOException {
		File fileDati = new File(filePath);
		
		if (!fileDati.exists()) {
			fileDati.createNewFile();
		}

		try (BufferedReader reader = new BufferedReader(new FileReader(fileDati))) {
			String lineaLetta;
			while ((lineaLetta = reader.readLine()) != null) {
				if (!lineaLetta.trim().isEmpty()) {
					campiBase.add(new CampoBase(lineaLetta.trim()));
				}
			}
		}

		if (campiBase.isEmpty()) {
			inizializzaCampiBaseObbligatorio(fileDati);
		}
	}


	/**
	 * Algoritmo guidato di inserimento manuale di configurazioni di base al primo boot.
	 * 
	 * @param fileDati Il riferimento al file destinazione fisico.
	 * @throws IOException Per la scrittura su un disco con permessi negati.
	 * 
	 * <p><b>Precondizioni:</b> {@code fileDati != null && fileDati.exists()}</p>
	 * <p><b>Postcondizioni:</b> L'utente ha inserito almeno un campo stringa in un ciclo controllato.</p>
	 */
	private void inizializzaCampiBaseObbligatorio(File fileDati) throws IOException {
		System.out.println("\n[SETUP INIZIALE] Il file campi_base.txt è vuoto. È obbligatorio inserirli ora:");
		
		try (PrintWriter writer = new PrintWriter(new FileWriter(fileDati))) {
			while (true) {
				String nomeCampo = it.unibs.fp.mylib.InputDati.leggiStringaNonVuota("Nome del nuovo Campo Base (scrivi 'FINE' per terminare): ");
				
				if (nomeCampo.equalsIgnoreCase("FINE")) {
					break;
				}
				
				campiBase.add(new CampoBase(nomeCampo));
				writer.println(nomeCampo);
			}
		}
	}

	/**
	 * Incorpora un nuovo Campo Comune alla lista estesa.
	 * 
	 * @param nome         Il nome descrittivo.
	 * @param obbligatorio Lo switch di obbligatorietà per il campo globale.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null && !nome.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Elemento aggiunto a {@code campiComuni}.</p>
	 */
	public void aggiungiCampoComune(String nome, boolean obbligatorio) {
		campiComuni.add(new CampoComune(nome, obbligatorio));
	}

	/**
	 * Pulisce e rimuove il Campo Comune individuandolo per nome (case-insensitive).
	 * 
	 * @param nome Il nome del campo da ricercare ed estirpare.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null}</p>
	 * <p><b>Postcondizioni:</b> Il nome passato viene rimosso dal pool dei comuni se presente.</p>
	 */
	public void rimuoviCampoComune(String nome) {
		campiComuni.removeIf(campo -> campo.getNome().equalsIgnoreCase(nome));
	}

	/**
	 * Modifica dinamicamente la proprietà di obbligatorietà di un campo comune salvato.
	 * 
	 * @param nome              Il nome del blocco in esame.
	 * @param rendiObbligatorio flag d'impostazione.
	 * 
	 * <p><b>Precondizioni:</b> {@code nome != null}</p>
	 * <p><b>Postcondizioni:</b> Stato di obbligatorietà aggiornato per il target (se fittato).</p>
	 */
	public void cambiaObbligatorietaComune(String nome, boolean rendiObbligatorio) {
		for (CampoComune campo : campiComuni) {
			if (campo.getNome().equalsIgnoreCase(nome)) {
				campo.setObbligatorio(rendiObbligatorio);
			}
		}
	}

	/**
	 * Instanzia una nuova Categoria di eventi.
	 * Se già esistente, l'avviso verrà bypassato prevenendo la sovrascrittura.
	 * 
	 * @param nomeCategoria Lo slug visibile per questa Categoria.
	 * 
	 * <p><b>Precondizioni:</b> {@code nomeCategoria != null && !nomeCategoria.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> La mappa delle categorie include il mapping a this nuova Categoria.</p>
	 */
	public void creaCategoria(String nomeCategoria) {
		categorie.putIfAbsent(nomeCategoria, new Categoria(nomeCategoria));
	}

	/**
	 * Distrugge una Categoria e tutti i rami/campi dipendenti.
	 * 
	 * @param nomeCategoria Il ramo da amputare.
	 * 
	 * <p><b>Precondizioni:</b> {@code nomeCategoria != null}</p>
	 * <p><b>Postcondizioni:</b> Nessuna entry con {@code nomeCategoria} come chiave rimane in memoria.</p>
	 */
	public void rimuoviCategoria(String nomeCategoria) {
		categorie.remove(nomeCategoria);
	}

	/**
	 * Integra un Campo Specifico apposito nel dizionario esatto della singola categoria.
	 * 
	 * @param nomeCategoria  Il contenitore.
	 * @param nomeCampo      La label del campo da introdurre in append.
	 * @param obbligatorio   Forzatura per form di caricamento o nullabilitá.
	 * 
	 * <p><b>Precondizioni:</b> {@code nomeCategoria != null && nomeCampo != null && !nomeCampo.trim().isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Se la categoria esiste, ha il nuovo campo aggiunto nei suoi campi specifici.</p>
	 */
	public void aggiungiCampoSpecifico(String nomeCategoria, String nomeCampo, boolean obbligatorio) {
		if (categorie.containsKey(nomeCategoria)) {
			Categoria categoriaScelta = categorie.get(nomeCategoria);
			categoriaScelta.aggiungiCampoSpecifico(new CampoSpecifico(nomeCampo, obbligatorio));
		} else {
			System.out.println("Errore: La categoria '" + nomeCategoria + "' non esiste.");
		}
	}

	/**
	 * Elimina selettivamente uno o molteplici (ridondanza) campi specifici di una categoria.
	 * 
	 * @param nomeCategoria  L'elemento madre in qui risiede il campo.
	 * @param nomeCampo      Target da obliterare.
	 * 
	 * <p><b>Precondizioni:</b> {@code nomeCategoria != null && nomeCampo != null}</p>
	 * <p><b>Postcondizioni:</b> Il campo è stato eventualmente droppato dalla categoria.</p>
	 */
	public void rimuoviCampoSpecifico(String nomeCategoria, String nomeCampo) {
		if (categorie.containsKey(nomeCategoria)) {
			Categoria categoriaScelta = categorie.get(nomeCategoria);
			categoriaScelta.getCampiSpecifici().removeIf(campo -> campo.getNome().equalsIgnoreCase(nomeCampo));
		}
	}


	/**
	 * Riversa su file in maniera serializzata personalizzata (plaintext CSV-like) 
	 * l'intero parco memoria di Comuni e Categorie (con relativi attributi nidificati).
	 * 
	 * @param filePath Dove destinare il backup logico.
	 * @throws IOException in caso di fallita acquisizione risorsa FileWriter.
	 * 
	 * <p><b>Precondizioni:</b> {@code filePath != null && !filePath.isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Sistema sincronizzato su file di testo.</p>
	 */
	public void salvaDati(String filePath) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
			writer.println("COMUNI");
			for (CampoComune campoComune : campiComuni) {
				writer.println(campoComune.getNome() + ";" + campoComune.isObbligatorio());
			}
			
			writer.println("CATEGORIE");
			for (Categoria categoria : categorie.values()) {
				writer.print(categoria.getNome());
				for (CampoSpecifico campoSpecifico : categoria.getCampiSpecifici()) {
					writer.print(";" + campoSpecifico.getNome() + "," + campoSpecifico.isObbligatorio());
				}
				writer.println();
			}
		}
	}


	/**
	 * Attinge dal salvataggio persistente e ricrea le classi Java in Runtime.
	 * Esegue un parsing posizionale custom per estrarre Comuni e Categorie dal flusso testuale.
	 * 
	 * @param filePath Documentazione target file .txt
	 * @throws IOException errore nella conversione dati in I/O.
	 * 
	 * <p><b>Precondizioni:</b> {@code filePath != null && !filePath.isEmpty()}</p>
	 * <p><b>Postcondizioni:</b> Variabili interne popolati se il file possiede pattern di default.</p>
	 */
	public void caricaDati(String filePath) throws IOException {
		File fileDati = new File(filePath);
		if (!fileDati.exists()) {
			return;
		}
		
		try (BufferedReader reader = new BufferedReader(new FileReader(fileDati))) {
			String sezioneCorrente = "";
			String lineaLetta;
			
			while ((lineaLetta = reader.readLine()) != null) {
				if (lineaLetta.equals("COMUNI") || lineaLetta.equals("CATEGORIE")) {
					sezioneCorrente = lineaLetta;
					continue;
				}
				
				if (sezioneCorrente.equals("COMUNI")) {
					String[] parti = lineaLetta.split(";");
					if (parti.length >= 2) {
						String nomeCampo = parti[0];
						boolean obbligatorio = Boolean.parseBoolean(parti[1]);
						campiComuni.add(new CampoComune(nomeCampo, obbligatorio));
					}
					
				} else if (sezioneCorrente.equals("CATEGORIE")) {
					String[] campiDati = lineaLetta.split(";");
					String nomeCategoria = campiDati[0];
					Categoria nuovaCategoria = new Categoria(nomeCategoria);
					
					for (int i = 1; i < campiDati.length; i++) {
						String[] datiCampoSpecifico = campiDati[i].split(",");
						if (datiCampoSpecifico.length >= 2) {
							String nomeSpecifico = datiCampoSpecifico[0];
							boolean obbligatorio = Boolean.parseBoolean(datiCampoSpecifico[1]);
							nuovaCategoria.aggiungiCampoSpecifico(new CampoSpecifico(nomeSpecifico, obbligatorio));
						}
					}
					categorie.put(nuovaCategoria.getNome(), nuovaCategoria);
				}
			}
		}
	}

	/**
	 * @return L'inventario della baseline di campi irremovibili.
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public List<CampoBase> getCampiBase() {
		return campiBase;
	}

	/**
	 * @return Variabili comuni attualmente attive per tutte le iniziative.
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public List<CampoComune> getCampiComuni() {
		return campiComuni;
	}

	/**
	 * @return Il pool di categorie create ed ammesse nel software dal configuratore.
	 * <p><b>Postcondizioni:</b> {@code return != null}</p>
	 */
	public Collection<Categoria> getCategorie() {
		return categorie.values();
	}
}