﻿package it.unibs.elaborato.v4;

import java.io.Serializable;

public abstract class Campo implements Serializable {
	private final String nome;
	private boolean obbligatorio;	// Precondizione: nome != null && !nome.trim().isEmpty()


	public Campo(String nome, boolean obbligatorio) {
		this.nome = nome;
		this.obbligatorio = obbligatorio;
	}
	// Postcondizione: this != null && this.nome == nome && this.obbligatorio == obbligatorio
	// Invariante: nome != null && !nome.trim().isEmpty()

	public String getNome() {
		return nome;
	}
	// Postcondizione: return != null && !return.trim().isEmpty()

	public boolean isObbligatorio() {
		return obbligatorio;
	}

	public void setObbligatorio(boolean obbligatorio) {
		this.obbligatorio = obbligatorio;
	}
	// Postcondizione: isObbligatorio() == obbligatorio

	@Override
	public String toString() {
		return nome + (obbligatorio ? " [Obbligatorio]" : " [Facoltativo]");
	}
	// Postcondizione: return != null && return.contains(nome)
}
