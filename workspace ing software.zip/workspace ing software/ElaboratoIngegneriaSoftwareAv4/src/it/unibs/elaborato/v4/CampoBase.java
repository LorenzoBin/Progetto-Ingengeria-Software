package it.unibs.elaborato.v4;

/**
 * Rappresenta un Campo Base definito a livello di sistema.
 * <p>
 * I Campi Base sono condivisi intrinsecamente da tutte le iniziative, a prescindere 
 * dalla categoria di appartenenza (es. "Titolo", "Numero partecipanti"). 
 * Sono strutturalmente <b>immutabili</b> nel loro stato di obbligatorieta', 
 * in quanto essenziali per il funzionamento minimo dell'applicazione.
 * </p>
 */
public class CampoBase extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Base. 
	 * Di default, viene forzato l'attributo obbligatorio a {@code true}.
	 * 
	 * @param nome Il nome univoco e descrittivo del Campo Base.
	 * 
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public CampoBase(String nome) {
		super(nome, true);
	}
	// Invariante: nome != null && !nome.trim().isEmpty()
	// Postcondizione: this != null && this.obbligatorio == true

	/**
	 * Impedisce la modifica dell'obbligatorieta' di un Campo Base.
	 * Essendo essenziali al sistema, questi campi rimangono sempre obbligatori.
	 * 
	 * @param obbligatorio Il nuovo stato (ignorato).
	 * @throws UnsupportedOperationException Sempre, per proteggere l'immutabilita' logica del campo.
	 * 
	 */
	@Override
	public void setObbligatorio(boolean obbligatorio) {
		throw new UnsupportedOperationException("I campi base sono immutabili e sempre obbligatori.");
	}
	// Postcondizione: isObbligatorio() == obbligatorio
}
