package it.unibs.elaborato.v4;

import java.io.*;
import java.util.*;

/**
 * Motore di accesso per ramificazione multipla dell'applicativo iterazione 3.
	 */
	public class SessioneLogin {
	private Map<String, String> configuratori = new HashMap<>();
	private Map<String, String> fruitori = new HashMap<>();
	private static final String ADMIN_MASTER = "admin";

	/**
	 * Check login the top-tier account
	 * @param u Usr
	 * @param p Psw
	 * @return Se u e p sono combacianti alle costanti hardcoded del root d'impianto.
	 */
	// Precondizione: u != null && p != null
	public boolean isMasterAdmin(String u, String p) {
		return ADMIN_MASTER.equals(u) && ADMIN_MASTER.equals(p);
	}

	/**
	 * Check credenziali trasversale ad ambo i branch d'utenza 
	 * @param u id pass
	 * @param p id lock
	 * @return Testo enum-like di flag ruolo se corretto ("CONFIGURATORE" o "FRUITORE"), altrimenti Null per login negato
	 */
	// Precondizione: u != null && p != null
	public String autentica(String u, String p) {
		if (configuratori.containsKey(u) && configuratori.get(u).equals(p))
			return "CONFIGURATORE";
		if (fruitori.containsKey(u) && fruitori.get(u).equals(p))
			return "FRUITORE";
		return null;
	}
	// Postcondizione: return == isOk

	/**
	 * @param u Nome identificativo
	 * @return Vero se lo username e' nel pool globale in uso sia Fruitori che Configuratori.
	 */
	// Precondizione: u != null && !u.isBlank()
	public boolean esisteGia(String u) {
		return configuratori.containsKey(u) || fruitori.containsKey(u) || ADMIN_MASTER.equalsIgnoreCase(u);
	}

	/**
	 * Iscrizione livello 1 admin
	 * @param u nome
	 * @param p psw
	 * @return se creata con successo
	 */
	// Precondizione: username sgombro && != null.
	public boolean registraConfiguratore(String u, String p) {
		if (esisteGia(u))
			return false;
		configuratori.put(u, p);
		return true;
	}
	// Postcondizione: esito ? map.size == map.size + 1 : map.size == unchanged

	/**
	 * Iscrizione livello 2 guest
	 * @param u usr
	 * @param p psw
	 * @return se creata con successo
	 */
	// Precondizione: username valid != null
	public boolean registraFruitore(String u, String p) {
		if (esisteGia(u))
			return false;
		fruitori.put(u, p);
		return true;
	}
	// Postcondizione: map == modified

	/**
	 * Esporta le chiavi per sicurezza offline in plain text CSV mode v4.
	 * @param path dest output
	 * @throws IOException 
	 */
	// Precondizione: path != null
	public void salva(String path) throws IOException {
		try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
			pw.println("CONFIGURATORI");
			for (Map.Entry<String, String> e : configuratori.entrySet())
				pw.println(e.getKey() + ";" + e.getValue());
			pw.println("FRUITORI");
			for (Map.Entry<String, String> e : fruitori.entrySet())
				pw.println(e.getKey() + ";" + e.getValue());
		}
	}
	// Postcondizione: file.header == 2 && fileSystem == aggiornato

	/**
	 * Rilegge credenziali riapplicando hashmap separate.
	 * @param path dest target filesystem res
	 * @throws IOException in failed seek read
	 */
	// Precondizione: path != null
	public void carica(String path) throws IOException {
		File f = new File(path);
		if (!f.exists())
			return;
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String l;
			String sez = "CONFIGURATORI";
			while ((l = br.readLine()) != null) {
				if (l.equals("CONFIGURATORI") || l.equals("FRUITORI")) {
					sez = l;
					continue;
				}
				String[] p = l.split(";");
				if (p.length >= 2) {
					if (sez.equals("CONFIGURATORI"))
						configuratori.put(p[0], p[1]);
					else
						fruitori.put(p[0], p[1]);
				}
			}
		}
	}
	// Postcondizione: file.exists ? loginMap.size >= 0 : loginMap.size == unchanged
}

