package it.unibs.elaborato.v4;

import java.util.*;

public class Categoria {
	private final String nome;
	private final List<CampoSpecifico> campiSpecifici = new ArrayList<>();	// Precondizione: nome != null && !nome.trim().isEmpty()


	public Categoria(String nome) {
		this.nome = nome;
	}
	// Postcondizione: this.nome == nome && campi.size == 0
	// Invariante: nome != null && campiSpecifici != null

	public String getNome() {
		return nome;
	}

	public List<CampoSpecifico> getCampiSpecifici() {
		return campiSpecifici;
	}
	// Postcondizione: return != null

	public void aggiungiCampoSpecifico(CampoSpecifico cs) {
		this.campiSpecifici.add(cs);
	}

	public void visualizza(List<CampoBase> base, List<CampoComune> comuni) {
		System.out.println("\n--- CATEGORIA: " + nome.toUpperCase() + " ---");
		System.out.println("Campi Base: " + base);
		System.out.println("Campi Comuni: " + comuni);
		System.out.println("Campi Specifici: " + campiSpecifici);
	}
}
