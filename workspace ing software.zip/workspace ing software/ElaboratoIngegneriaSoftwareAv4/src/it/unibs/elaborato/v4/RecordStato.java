package it.unibs.elaborato.v4;

import java.time.LocalDate;

/**
 * Tracciabilit       immutabile del cambio di stato subito da una proposta, vitale per la logistica.
	 */
	public class RecordStato {
	private String stato;
	private LocalDate data;

	/**
	 * @param stato Testo stato formalizzato
	 * @param data Date of translation
	 */
	// Precondizione: Parametri costruttore validi not-nulls.
	public RecordStato(String stato, LocalDate data) {
		this.stato = stato;
		this.data = data;
	}
	// Invariante: stato != null && dataInizio != null
	// Postcondizione: snapshot != null

	/** 
	 * @return Etichetta verbale fase attraversata (es. Confermata, Annullata).
	 */
	public String getStato() {
		return stato;
	}
	// Postcondizione: return != null

	/** 
	 * @return Giorno locale
	 */
	public LocalDate getData() {
		return data;
	}
	// Postcondizione: return != null

	@Override
	public String toString() {
		return stato + " (" + ValidatoreData.format(data) + ")";
	}
	// Postcondizione: return != null && return.contains(nome)
}

