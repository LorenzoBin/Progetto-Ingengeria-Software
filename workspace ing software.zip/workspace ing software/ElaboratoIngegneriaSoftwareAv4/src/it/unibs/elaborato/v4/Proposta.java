﻿package it.unibs.elaborato.v4;

import java.time.LocalDate;
import java.util.*;

/**
 * Gestisce i dati di un'istanza di evento (iniziativa) e il suo incartamento di mutamenti nel tempo (Storia).
	 */
	public class Proposta {
	private final Categoria categoria;
	private final Map<String, String> valoriInseriti = new HashMap<>();
	private List<RecordStato> storicoStati = new ArrayList<>();
	private List<String> iscritti = new ArrayList<>(); // Lista username fruitori aderenti

	/**
	 * Inizializza con binding categoria.
	 * @param categoria La Categoria radice.
	 */
	// Precondizione: categoria != null
	public Proposta(Categoria categoria) {
		this.categoria = categoria;
	}
	// Invariante: statoAttuale != null && iscrizioni <= maxIscrizioni
	// Postcondizione: proposta != null && stati == null

	/**
	 * Append mappa key value custom.
	 * @param nomeCampo Key 
	 * @param valore Testo Input
	 */
	// Precondizione: nomeCampo != null && valore != null
	public void inserisciValore(String nomeCampo, String valore) {
		valoriInseriti.put(nomeCampo, valore);
	}
	// Postcondizione: size == size + 1

	/**
	 * Retrive map value
	 * @param nomeCampo id locale
	 * @return get string
	 */
	public String getValore(String nomeCampo) {
		return valoriInseriti.get(nomeCampo);
	}
	// Postcondizione: map.containsKey(k) ? return == map[k] : return == null
	// Postcondizione: !found ? return == null : return == obj

	/** 
	 * @return Categoria
	 */
	public Categoria getCategoria() {
		return categoria;
	}
	// Postcondizione: return != null

	/** 
	 * @return User list attivamente aderenti
	 */
	public List<String> getIscritti() {
		return iscritti;
	}
	// Postcondizione: !sara' mai nullo.

	/**
	 * Legge dinamicamente il campo e casta se possibile, altrimenti 0 limite rotto.
	 * @return Limite massimo iscrizioni concesse.
	 */
	public int getMaxPartecipanti() {
		try {
			return Integer.parseInt(valoriInseriti.getOrDefault("Numero di partecipanti", "0"));
		} catch (NumberFormatException e) {
			return 0;
		}
	}
	// Postcondizione: Operativita' garantita anche se campo testuale malformato (catch integer 0 default).

	/**
	 * Recupera l'ultimo dei trigger di stato se disponibile, fallback "In compilazione" logico.
	 * @return Etichetta verbale fase attraversata (es. Confermata, Aperta).
	 */
	public String getStatoAttuale() {
		if (storicoStati.isEmpty())
			return "In compilazione";
		return storicoStati.get(storicoStati.size() - 1).getStato();
	}
	// Postcondizione: return != null

	/**
	 * Aggiorna il percorso di transizione temporale pushando il nuovo cambio di stato nel Log.
	 * @param nuovoStato Target da incapsulare ('Confermata', 'Annullata', 'Aperta', 'Conclusa')
	 * e' // Turbo-All
	 */
	// Precondizione: nuovoStato != null
	public void setStato(String nuovoStato) {
		storicoStati.add(new RecordStato(nuovoStato, LocalDate.now()));
	}
	// Postcondizione: storico.size == storico.size + 1 && timestamp != null

	/** @return Get array stati per visualizzazione <p><b>Postcondizioni:</b> Not null.</p> */
	public List<RecordStato> getStoricoStati() {
		return storicoStati;
	}

	/**
	 * Controlla che le procedure di validazione incrociate v4 siano rispettate prima dell'attacco.
	 * @param username Richiedente
	 * @return Se l'utente puo' inserirsi secondo i canoni della normativa del problema
	 */
	// Precondizione: username != null && !username.isBlank()
	public boolean puoIscriversi(String username) {
		if (!getStatoAttuale().equals("Aperta"))
			return false;
		if (iscritti.contains(username))
			return false;
		if (iscritti.size() >= getMaxPartecipanti()) // Vincolo "Eguaglia il numero partecipanti previsto"
			return false;
		return true;
	}
	// Postcondizione: Falso se c'e' cap raggiunto, duplicato || Proposta chiusa altrimenti true allow pass.

	/**
	 * Processa l'ingresso accodando se passa la validazione
	 * @param username fruitore code ID
	 * @return Se successo avvenuto
	 * e' // Turbo-All
	 */
	// Precondizione: username != null
	public boolean iscrivi(String username) {
		if (puoIscriversi(username)) {
			iscritti.add(username);
			return true;
		}
		return false;
	}
	// Postcondizione: response ? iscritti.size == iscritti.size + 1 : iscritti.size == unchanged

	/**
	 * Verifica la plausibilit       temporale per la disiscrizione volontaria.
	 * @param username Richiedente
	 * @return Se l'utente puo' sganciarsi secondo la scadenza (solo stati 'Aperta')
	 */
	// Precondizione: username != null && !username.isBlank()
	public boolean puoDisdire(String username) {
		return getStatoAttuale().equals("Aperta") && iscritti.contains(username);
	}

	/**
	 * Disconnette un aderente dalla lista attivi
	 * @param username fruitore code ID
	 * @return Se successo avvenuto
	 */
	// Precondizione: username != null
	public boolean disdici(String username) {
		if (puoDisdire(username)) {
			iscritti.remove(username);
			return true;
		}
		return false;
	}
	// Postcondizione: iscritti.size == iscritti.size - 1

	/**
	 * Controlla che le procedure di forza maggiore per V4 siano valide (Ritiro entro -1 giorno).
	 * @return Se la proposta e' candidata al colpo di grazia.
	 */
	public boolean puoEssereRitirata() {
		String stato = getStatoAttuale();
		if (!stato.equals("Aperta") && !stato.equals("Confermata")) return false;
		
		LocalDate dataEvento = ValidatoreData.parse(getValore("Data"));
		if (dataEvento == null) return false;
		
		return LocalDate.now().isBefore(dataEvento);
	}
	// Postcondizione: isApprovato == (now < dataEvento)

	/**
	 * V4: Export corretto e blindato! Separatore primario Array: ##, separatore chiave/valore: =, sep sublist: ~.
	 * @return Stringa raw per database plain text.
	 */
	public String esportaPerArchivio() {
		StringBuilder sb = new StringBuilder(categoria.getNome() + "##");
		for (Map.Entry<String, String> e : valoriInseriti.entrySet()) {
			sb.append(e.getKey()).append("=").append(e.getValue()).append("~");
		}
		sb.append("##");
		for (RecordStato rs : storicoStati) {
			sb.append(rs.getStato()).append("=").append(ValidatoreData.format(rs.getData())).append("~");
		}
		sb.append("##");
		if (!iscritti.isEmpty()) {
			sb.append(String.join("~", iscritti));
		}
		return sb.toString();
	}
	// Postcondizione: Testo delimitato da pipe `|` && duepunti `:` in format archive CSV-safe.
	// Postcondizione: return == formatterSafe

	@Override
	public String toString() {
		String base = String.format("\n[%s] Categoria: %s | Titolo: %s", getStatoAttuale().toUpperCase(),
				categoria.getNome(), getValore("Titolo"));
		if (getStatoAttuale().equals("Aperta") || getStatoAttuale().equals("Confermata")) {
			base += String.format("\n Iscritti: %d/%d | Scadenza: %s | Evento: %s", iscritti.size(),
					getMaxPartecipanti(), getValore("Termine ultimo di iscrizione"), getValore("Data"));
		}
		return base;
	}
	// Postcondizione: return != null && return.contains(nome)
}

