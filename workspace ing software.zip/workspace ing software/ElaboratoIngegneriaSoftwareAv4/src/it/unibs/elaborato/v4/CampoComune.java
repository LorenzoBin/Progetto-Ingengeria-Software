package it.unibs.elaborato.v4;

public class CampoComune extends Campo {	// Precondizione: nome != null && !nome.trim().isEmpty()

	public CampoComune(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
	// Postcondizione: campoComune != null
	// Invariante: nome != null && !nome.trim().isEmpty()
}
