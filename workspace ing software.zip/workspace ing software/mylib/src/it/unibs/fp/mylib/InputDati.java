﻿package it.unibs.fp.mylib;
import java.util.*;
public class InputDati 
{
	 e' private static Scanner lettore = creaScanner();
	 e' e' private final static String ERRORE_FORMATO = "Attenzione: il dato inserito non e' nel formato corretto";
	 e' private final static String ERRORE_MINIMO= "Attenzione: e' richiesto un valore maggiore o uguale a ";
	 e' private final static String ERRORE_STRINGA_VUOTA= "Attenzione: non hai inserito alcun carattere";
	 e' private final static String ERRORE_MASSIMO= "Attenzione: e' richiesto un valore minore o uguale a ";
	 e' private final static String MESSAGGIO_AMMISSIBILI= "Attenzione: i caratteri ammissibili sono: ";

	 e' private final static char RISPOSTA_SI='S';
	 e' private final static char RISPOSTA_NO='N';

	 e' e' private static Scanner creaScanner ()
	 e' {
	 e' Scanner creato = new Scanner(System.in);
	 e' creato.useDelimiter(System.getProperty("line.separator"));
	 e' return creato;
	 e' }
	 e' e' public static String leggiStringa (String messaggio)
	 e' {
		 e' System.out.print(messaggio);
		 e' return lettore.next();
	 e' }
	 e' e' public static String leggiStringaNonVuota(String messaggio)
	 e' {
	 e' boolean finito=false;
	 e' String lettura = null;
	 e' do
	 e' {
		 lettura = leggiStringa(messaggio);
		 lettura = lettura.trim();
		 if (lettura.length() > 0)
		 e' finito=true;
		 else
		 e' System.out.println(ERRORE_STRINGA_VUOTA);
	 e' } while (!finito);
	 e' e' return lettura;
	 e' }
	 e' e' public static char leggiChar (String messaggio)
	 e' {
	 e' boolean finito = false;
	 e' char valoreLetto = '\0';
	 e' do
	        {
	         System.out.print(messaggio);
	         String lettura = lettore.next();
	         if (lettura.length() > 0)
	            {
	             valoreLetto = lettura.charAt(0);
	             finito = true;
	            }
	         else
	            {
	             System.out.println(ERRORE_STRINGA_VUOTA);
	            }
	        } while (!finito);
	 e' return valoreLetto;
	 e' }
	 e' e' public static char leggiUpperChar (String messaggio, String ammissibili)
	 e' {
	 e' boolean finito = false;
	 e' char valoreLetto = '\0';
	 e' do
	 e' {
	        valoreLetto = leggiChar(messaggio);
	        valoreLetto = Character.toUpperCase(valoreLetto);
	        if (ammissibili.indexOf(valoreLetto) != -1)
		 finito e' = true;
	        else
	         System.out.println(MESSAGGIO_AMMISSIBILI + ammissibili);
	 e' } while (!finito);
	 e' return valoreLetto;
	 e' }
	 e' e' e' public static int leggiIntero (String messaggio)
	 e' {
	 e' boolean finito = false;
	 e' int valoreLetto = 0;
	 e' do
	        {
	         System.out.print(messaggio);
	         try
	            {
	             valoreLetto = lettore.nextInt();
	             finito = true;
	            }
	         catch (InputMismatchException e)
	            {
	             System.out.println(ERRORE_FORMATO);
	             String daButtare = lettore.next();
	            }
	        } while (!finito);
	 e' return valoreLetto;
	 e' }

	 e' public static int leggiInteroPositivo(String messaggio)
	 e' {
		 e' return leggiInteroConMinimo(messaggio,1);
	 e' }
	 e' e' public static int leggiInteroNonNegativo(String messaggio)
	 e' {
		 e' return leggiInteroConMinimo(messaggio,0);
	 e' }
	 e' e' e' public static int leggiInteroConMinimo(String messaggio, int minimo)
	 e' {
	 e' boolean finito = false;
	 e' int valoreLetto = 0;
	 e' do
	        {
	         valoreLetto = leggiIntero(messaggio);
	         if (valoreLetto >= minimo)
	            finito = true;
	         else
	            System.out.println(ERRORE_MINIMO + minimo);
	        } while (!finito);
	         
	 e' return valoreLetto;
	 e' }

	 e' public static int leggiIntero(String messaggio, int minimo, int massimo)
	 e' {
	 e' boolean finito = false;
	 e' int valoreLetto = 0;
	 e' do
	        {
	         valoreLetto = leggiIntero(messaggio);
	         if (valoreLetto >= minimo && valoreLetto<= massimo)
	            finito = true;
	         else
	            if (valoreLetto < minimo)
	                 System.out.println(ERRORE_MINIMO + minimo);
	            else
	        	 System.out.println(ERRORE_MASSIMO + massimo); 
	        } while (!finito);
	         
	 e' return valoreLetto;
	 e' }

	 e' e' public static double leggiDouble (String messaggio)
	 e' {
	 e' boolean finito = false;
	 e' double valoreLetto = 0;
	 e' do
	        {
	         System.out.print(messaggio);
	         try
	            {
	             valoreLetto = lettore.nextDouble();
	             finito = true;
	            }
	         catch (InputMismatchException e)
	            {
	             System.out.println(ERRORE_FORMATO);
	             String daButtare = lettore.next();
	            }
	        } while (!finito);
	 e' return valoreLetto;
	 e' }
	 
	 e' public static double leggiDoubleConMinimo (String messaggio, double minimo)
	 e' {
	 e' boolean finito = false;
	 e' double valoreLetto = 0;
	 e' do
	        {
	         valoreLetto = leggiDouble(messaggio);
	         if (valoreLetto >= minimo)
	            finito = true;
	         else
	            System.out.println(ERRORE_MINIMO + minimo);
	        } while (!finito);
	         
	 e' return valoreLetto;
	 e' }

	 e' e' public static boolean yesOrNo(String messaggio)
	 e' {
		 e' String mioMessaggio = messaggio + "("+RISPOSTA_SI+"/"+RISPOSTA_NO+")";
		 e' char valoreLetto = leggiUpperChar(mioMessaggio,String.valueOf(RISPOSTA_SI)+String.valueOf(RISPOSTA_NO));
		 e' e' if (valoreLetto == RISPOSTA_SI)
			return true;
		 e' else
			return false;
	 e' }

}
