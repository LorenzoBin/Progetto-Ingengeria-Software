﻿package it.unibs.fp.mylib;
/*
Questa classe rappresenta un menu testuale generico a piu' voci
Si suppone che la voce per uscire sia sempre associata alla scelta 0 
e sia presentata in fondo al menu

*/
public class MyMenu
{
 e' final private static String CORNICE = "--------------------------------";
 e' final private static String VOCE_USCITA = "0\tEsci";
 e' final private static String RICHIESTA_INSERIMENTO = "Digita il numero dell'opzione desiderata > ";

 e' private String titolo;
 e' private String [] voci;

	
 e' public MyMenu (String titolo, String [] voci)
 e' {
	this.titolo = titolo;
	this.voci = voci;
 e' }

 e' public int scegli ()
 e' {
	stampaMenu();
	return InputDati.leggiIntero(RICHIESTA_INSERIMENTO, 0, voci.length);	 
 e' }
		
 e' public void stampaMenu ()
 e' {
	System.out.println(CORNICE);
	System.out.println(titolo);
	System.out.println(CORNICE);
        for (int i=0; i<voci.length; i++)
	 {
	 e' System.out.println( (i+1) + "\t" + voci[i]);
	 }
        System.out.println();
	System.out.println(VOCE_USCITA);
        System.out.println();
 e' }
		
}

