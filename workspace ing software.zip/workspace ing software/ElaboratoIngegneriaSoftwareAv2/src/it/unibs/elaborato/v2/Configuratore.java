package it.unibs.elaborato.v2;

import java.io.*;
import java.util.*;
import java.time.LocalDate;
import it.unibs.fp.mylib.InputDati;

/**
 * Logica di business per la gestione di campi, categorie, bozze e bacheca.
	 */
	public class Configuratore {
	private List<CampoBase> campiBase;
	private List<CampoComune> campiComuni;
	private Map<String, Categoria> categorie;
	
	private Bacheca bachecaReale; // Persistente
	private List<Proposta> bozze; // Volatile (Memoria RAM)

	/**
	 */
	public Configuratore() {
		this.campiBase = new ArrayList<>();
		this.campiComuni = new ArrayList<>();
		this.categorie = new HashMap<>();
		this.bachecaReale = new Bacheca();
		this.bozze = new ArrayList<>();
	}
	// Postcondizione: attributi != null

	/**
	 * Carica i campi base, se il file e' vuoto obbliga la creazione manuale in Console.
	 * @param path File system destination.
	 * @throws IOException in caso di errata I/O file operation.
	 */
	// Precondizione: path != null && !path.isBlank()
	public void caricaOInizializzaCampiBase(String path) throws IOException {
		File f = new File(path);
		if (!f.exists())
			f.createNewFile();

		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String l;
			while ((l = br.readLine()) != null) {
				if (!l.trim().isEmpty())
					campiBase.add(new CampoBase(l.trim()));
			}
		}

		if (campiBase.isEmpty()) {
			System.out.println("\n[SETUP] Il file campi_base.txt e' vuoto. Inserimento obbligatorio:");
			System.out.println("NOTA PER V2: Assicurati di inserire i campi 'Termine ultimo di iscrizione' e 'Data' per far funzionare correttamente le Iniziative!");
			try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
				while (true) {
					String nome = InputDati.leggiStringaNonVuota("Nome del nuovo Campo Base (scrivi 'FINE' per terminare): ");
					if (nome.equalsIgnoreCase("FINE"))
						break;
					campiBase.add(new CampoBase(nome));
					pw.println(nome);
				}
			}
		}
	}
	// Postcondizione: RAM == restored

	/**
	 * Aggiunge un nuovo Campo Comune alla dotazione.
	 * @param n Label identificativo del campo.
	 * @param o Switch della logica boolean null-safe su UI console.
	 */
	// Precondizione: n != null && !n.isBlank()
	public void aggiungiCampoComune(String n, boolean o) { campiComuni.add(new CampoComune(n, o)); }
	// Postcondizione: list.size == list.size + 1

	/**
	 * Eviscera i campi cercandoli per nome migrazione.
	 * @param n Label identificativo campo in uppercase / ignorato.
	 */
	// Precondizione: n != null
	public void rimuoviCampoComune(String n) { campiComuni.removeIf(c -> c.getNome().equalsIgnoreCase(n)); }
	// Postcondizione: found ? list.size == list.size - 1 : state == inalterato
	
	/**
	 * Ribalta stato del check optional/required di quel target in particolare.
	 * @param n Label identificativo campo
	 * @param o Flag nuovo value booleano
	 */
	// Precondizione: n != null
	public void cambiaObbligatorietaComune(String n, boolean o) {
		for (CampoComune c : campiComuni) if (c.getNome().equalsIgnoreCase(n)) c.setObbligatorio(o);
	}
	// Postcondizione: found ? campo.modificato == true : state == inalterato

	/**
	 * Nuova entry per il database.
	 * @param n Slug Categoria root.
	 */
	// Precondizione: n != null && !n.isBlank()
	public void creaCategoria(String n) { categorie.putIfAbsent(n, new Categoria(n)); }
	// Postcondizione: !exists ? hashmap.containsKey(nome) == true : state == inalterato

	/**
	 * Rimozione traccia memoria. 
	 * @param n identifier della categoria radice abolita
	 */
	// Precondizione: n != null
	public void rimuoviCategoria(String n) { categorie.remove(n); }
	// Postcondizione: Array category key !piu' rintracciabile
	
	/**
	 * Branch specifico inserito solo x questa specifica logica d'afferenza a Categoria
	 * @param cat Id Categoria
	 * @param n Id nuovo campo specifico
	 * @param o Requirement status boolean
	 */
	// Precondizione: n != null && cat != null
	public void aggiungiCampoSpecifico(String cat, String n, boolean o) {
		if (categorie.containsKey(cat)) categorie.get(cat).aggiungiCampoSpecifico(new CampoSpecifico(n, o));
	}
	// Postcondizione: cat == match ? class.list == salvata : class.list == unchanged

	/**
	 * Branch specifico rimosso solo x questa specifica logica d'afferenza a Categoria
	 * @param cat Id Categoria
	 * @param n Id campo specifico target remove
	 */
	// Precondizione: n != null && cat != null
	public void rimuoviCampoSpecifico(String cat, String n) {
		if (categorie.containsKey(cat)) categorie.get(cat).getCampiSpecifici().removeIf(c -> c.getNome().equalsIgnoreCase(n));
	}
	// Postcondizione: list.size == 0

	/**
	 * Verifica il rispetto stringente dei vincoli formativi e temporali di una bozza (V2).
	 * @param p Proposta da testare
	 * @return Booleano confermativo (True ok, False respinta).
	 */
	// Precondizione: p != null
	public boolean validaProposta(Proposta p) {
		for (CampoBase cb : campiBase) 
			if (p.getValore(cb.getNome()) == null || p.getValore(cb.getNome()).isBlank()) return false;
		
		for (CampoComune cc : campiComuni) 
			if (cc.isObbligatorio() && (p.getValore(cc.getNome()) == null || p.getValore(cc.getNome()).isBlank())) return false;
		
		for (CampoSpecifico cs : p.getCategoria().getCampiSpecifici()) 
			if (cs.isObbligatorio() && (p.getValore(cs.getNome()) == null || p.getValore(cs.getNome()).isBlank())) return false;

		LocalDate t = ValidatoreData.parse(p.getValore("Termine ultimo di iscrizione"));
		LocalDate d = ValidatoreData.parse(p.getValore("Data"));

		return ValidatoreData.isTermineValido(t) && ValidatoreData.isDistanzaMinimaRispettata(t, d);
	}
	// Postcondizione: oggetto == unchanged

	/**
	 * Aggiunge la proposta validata alle Bozze della sessione corrente.
	 * @param p Proposta in pre-approvazione.
	 */
	// Precondizione: p != null
	public void aggiungiBozza(Proposta p) {
		if (validaProposta(p)) {
			p.setStato("Valida"); 
			bozze.add(p);
		}
	}
	// Postcondizione: validata == true ? stato == "Valida" && bozze.size == bozze.size + 1 : state == inalterato

	/**
	 * @return Getter liste array per display terminale
	 */
	public List<Proposta> getBozze() {
		return bozze;
	}
	// Postcondizione: return != null

	/**
	 * Sposta dalla memoria volatile alla raccolta persistente marcandola Aperta.
	 * @param indice Puntatore scalare per ArrayList (0-based).
	 * @return Ritorna vero qualora lo skip non incroci out of range list error.
	 */
	// Precondizione: indice >= 0
	public boolean pubblicaBozza(int indice) {
		if (indice >= 0 && indice < bozze.size()) {
			Proposta p = bozze.remove(indice); 
			p.setStato("Aperta");                            
			p.setDataPubblicazione(LocalDate.now());
			bachecaReale.aggiungi(p);                    
			return true;
		}
		return false;
	}
	// Postcondizione: list.size == list.size - 1 && obj.stato == modified

	/**
	 * Wrapper output system view. Stampa sul display le righe rintracciate
	 * @param nomeCat Stringa in ricerca nel filter di bacheca
	 */
	// Precondizione: nomeCat != null
	public void visualizzaBachecaFiltrata(String nomeCat) {
		List<Proposta> filtrate = bachecaReale.filtraPerCategoria(nomeCat);
		System.out.println("\n--- BACHECA CATEGORIA: " + nomeCat.toUpperCase() + " ---");
		if (filtrate.isEmpty()) {
			System.out.println("Nessuna proposta aperta trovata in questa categoria.");
		} else {
			filtrate.forEach(System.out::println);
		}
	}
	// Postcondizione: sistema == unchanged

	/**
	 * Wrapper globale stampante intera lista per utenze non categoriche
	 */
	public void visualizzaBachecaIntera() {
		List<Proposta> tutte = bachecaReale.getTutte();
		System.out.println("\n--- INTERA BACHECA ---");
		if (tutte.isEmpty()) {
			System.out.println("La bacheca e' attualmente vuota.");
		} else {
			tutte.forEach(System.out::println);
		}
	}
	// Postcondizione: stream == unchanged

	/**
	 * Costruisce le istruzioni filewriter e committa tutto l'albero cache
	 * @param path dest output raw text db relative URI
	 * @throws IOException in caso di errata I/O stream fallace locale
	 */
	// Precondizione: path != null && !path.isBlank()
	public void salvaDati(String path) throws IOException {
		try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
			pw.println("COMUNI");
			for (CampoComune cc : campiComuni)
				pw.println(cc.getNome() + ";" + cc.isObbligatorio());
			
			pw.println("CATEGORIE");
			for (Categoria cat : categorie.values()) {
				pw.print(cat.getNome());
				for (CampoSpecifico cs : cat.getCampiSpecifici())
					pw.print(";" + cs.getNome() + "," + cs.isObbligatorio());
				pw.println();
			}

			pw.println("ARCHIVIO_PROPOSTE");
			for (Proposta p : bachecaReale.getTutte()) {
				pw.println(p.esportaPerArchivio());
			}
		}
	}
	// Postcondizione: fileSystem == aggiornato && !hasExceptions

	/**
	 * Restituisce ai moduli array base Java tutto il txt di backup convertendo
	 * pattern string in Boolean (obbligatorieta') e Categoria hashmap string split.
	 * @param path dest target db txt
	 * @throws IOException in caso lettore corrotto
	 */
	// Precondizione: path != null
	public void caricaDati(String path) throws IOException {
		File f = new File(path);
		if (!f.exists()) return;
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String sezione = "", l;
			while ((l = br.readLine()) != null) {
				if (l.equals("COMUNI") || l.equals("CATEGORIE") || l.equals("ARCHIVIO_PROPOSTE")) {
					sezione = l;
					continue;
				}
				if (sezione.equals("COMUNI")) {
					String[] p = l.split(";");
					campiComuni.add(new CampoComune(p[0], Boolean.parseBoolean(p[1])));
				} else if (sezione.equals("CATEGORIE")) {
					String[] p = l.split(";");
					Categoria c = new Categoria(p[0]);
					for (int i = 1; i < p.length; i++) {
						String[] d = p[i].split(",");
						c.aggiungiCampoSpecifico(new CampoSpecifico(d[0], Boolean.parseBoolean(d[1])));
					}
					categorie.put(c.getNome(), c);
				} else if (sezione.equals("ARCHIVIO_PROPOSTE")) {
					String[] p = l.split("\\|");
					Categoria cat = categorie.get(p[0]);
					if (cat != null) {
						Proposta prop = new Proposta(cat);
						if (p.length > 2) {
							prop.setDataPubblicazione(LocalDate.parse(p[1]));
							prop.setStato(p[2]);
							for (int i = 3; i < p.length; i++) {
								String[] kv = p[i].split(":", 2);
								if (kv.length == 2) prop.inserisciValore(kv[0], kv[1]);
							}
							bachecaReale.aggiungi(prop);
						}
					}
				}
			}
		}
	}
	// Postcondizione: file.ok ? cache == reloaded : cache == empty

	/** @return get base <p><b>Postcondizioni:</b> {@code return != null}</p>*/
	public List<CampoBase> getCampiBase() { return campiBase; }
	/** @return get comuni <p><b>Postcondizioni:</b> {@code return != null}</p>*/
	public List<CampoComune> getCampiComuni() { return campiComuni; }
	/** @return get col. cat <p><b>Postcondizioni:</b> {@code return != null}</p>*/
	public Collection<Categoria> getCategorie() { return categorie.values(); }
}

