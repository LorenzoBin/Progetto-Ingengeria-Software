﻿package it.unibs.elaborato.v2;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.format.ResolverStyle;
import java.time.temporal.ChronoUnit;

/**
 * Utility per gestire e validare le stringhe e stringhe in date e per imporre i 
 * vincoli logico-temporali della Versione 2.
	 */
	public class ValidatoreData {
        private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("dd/MM/uuuu")
                        .withResolverStyle(ResolverStyle.STRICT);

        /**
         * Intercetta una stringa e la decodifica in caso il formato sia DD/MM/YYYY.
	 * 
	 * @param dataStr Formattata raw utente
         * @return L'oggetto parsato. Se fallisce o non supportato torna Null. 
         * 
	 */
	// Precondizione: Nessuna restrizione logica in input bypassata in trycatch.
	public static LocalDate parse(String dataStr) {
                try {
                        if (dataStr == null || dataStr.trim().isEmpty()) return null;
                        return LocalDate.parse(dataStr.trim(), FORMATTER);
                } catch (DateTimeParseException e) {
                        return null;
                }
        }
	// Postcondizione: return == LocalDate || return == null

        /**
         * Verifica la strict posteriorita' di una data rispetto all'orario attuale.
	 * 
	 * @param termine Data inserita e parsata.
         * @return boolean dell'esito.
         * 
	 */
	// Precondizione: Nessuna, accetta anche Null ritornando false in quel caso.
	public static boolean isTermineValido(LocalDate termine) {
                LocalDate oggi = LocalDate.now();
                return termine != null && termine.isAfter(oggi);
        }
	// Postcondizione: return == termine != null && termine.isAfter(LocalDate.now())

        /**
         * Calcola la distanza aritmetica in ChronoDays e ne approva il differenziale >= 2.
	 * 
	 * @param termine Ultima data d'iscrizione consentita
         * @param inizioEvento La giornata per l'iniziativa
         * @return test passato logicamente se distanza d'assunzione tollerata dal sistema
         * 
	 */
	// Precondizione: Entrambe le entita' passate !determinatamente nulle.
	public static boolean isDistanzaMinimaRispettata(LocalDate termine, LocalDate inizioEvento) {
                if (termine == null || inizioEvento == null) return false;
                long giorni = ChronoUnit.DAYS.between(termine, inizioEvento);
                return giorni >= 2; // Almeno due giorni di differenza
        }
	// Postcondizione: return == (timeDiff >= 2)

        /**
         * Offusca i dati per l'esportazione verso output stream / file raw txt.
	 */
	public static String format(LocalDate data) {
                return (data == null) ? "N/A" : data.format(FORMATTER);
        }
	// Postcondizione: this != null ? return == format(this) : return == "N/A"
}

