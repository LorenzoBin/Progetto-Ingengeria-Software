﻿package it.unibs.elaborato.v2;

import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;

/**
 * Gestisce i dati di un'istanza di evento (iniziativa).
	 */
	public class Proposta {
        private final Categoria categoria;
        private final Map<String, String> valoriInseriti = new HashMap<>();
        private String stato; 
        private LocalDate dataPubblicazione;

        /**
         * Crea un'istanza legata obbligatoriamente a una Categoria strutturata.
	 * 
	 * @param categoria La Categoria base
	 */
	// Precondizione: categoria != null
	public Proposta(Categoria categoria) {
                this.categoria = categoria;
                this.stato = "In compilazione";
        }
	// Invariante: statoAttuale != null && iscrizioni <= maxIscrizioni
	// Postcondizione: proposta != null && stato == "In Compilazione" && hashmap.size == 0

        /**
         * Aggiunge o sovrascrive un valore dinamico legato a uno dei campi della categoria.
	 * 
	 * @param nomeCampo nome stringa identificativo
         * @param valore stringa data testuale associata
	 */
	// Precondizione: nomeCampo != null && !nomeCampo.isBlank() && valore != null
	public void inserisciValore(String nomeCampo, String valore) {
                valoriInseriti.put(nomeCampo, valore);
        }
	// Postcondizione: Il valore e' correttamente registrato per la chiave di quel campo.

        /**
         * Estrae testualmente il dato configurato dal momento della compilazione bozza.
	 * 
	 * @param nomeCampo nome stringa identificativo (identifier string)
         * @return IL contenuto inserito dall'utente finale
	 */
	// Precondizione: nomeCampo != null
	public String getValore(String nomeCampo) {
                return valoriInseriti.get(nomeCampo);
        }
	// Postcondizione: map.containsKey(k) ? return == map[k] : return == null

        /**
         * Espone la condizione astratta della bozza.
	 * 
	 * @return Lo stato logico corrente (es. Valida, Aperta, In compilazione)
         */
 public String getStato() { return stato; }
 // Postcondizione: return != null
        
        /** 
         * Modifica attivamente il permesso di archiviazione o vista al pubblico della riga in bacheca.
	 * 
	 * @param stato Nuovo stato "Valida" o "Aperta" 
	 */
	// Precondizione: stato != null && !stato.isBlank()
	public void setStato(String stato) { this.stato = stato; }
	// Postcondizione: La proposta ora e' segnata col nuovo descrittore testuale del database.
        
        /** 
         * Imposta il momento esatto in cui ha raggiunto la visibilita' all'utenza.
	 * 
	 * @param data L'istanza formale del momento temporale locale della macchina.
	 */
	// Precondizione: data != null
	public void setDataPubblicazione(LocalDate data) { this.dataPubblicazione = data; }
	// Postcondizione: dataPubblicazione == now()
        
        /** 
         * @return La struttura algebrica che identifica i metadati comuni
         */
	public Categoria getCategoria() { return categoria; }
	// Postcondizione: return != null

        /**
         * Codifica l'oggetto per formattarlo su file system bypassando la complessa astrazione java.
	 * 
	 * @return Formato stringa serializzabile di valori chiave/valore concatenati.
         */
 public String esportaPerArchivio() {
                StringBuilder sb = new StringBuilder();
                sb.append(categoria.getNome()).append("|")
                    .append(dataPubblicazione).append("|")
                    .append(stato);
                for (Map.Entry<String, String> entry : valoriInseriti.entrySet()) {
                        sb.append("|").append(entry.getKey()).append(":").append(entry.getValue());
                }
                return sb.toString();
        }
 // Postcondizione: Testo delimitato da pipe `|` && duepunti `:` in format archive CSV-safe.

        @Override
        public String toString() {
                return String.format("\n[PROPOSTA %s] Categoria: %s\nPubblicata il: %s\nDati: %s", e' stato.toUpperCase(), categoria.getNome(), ValidatoreData.format(dataPubblicazione), valoriInseriti);
        }
}

