﻿package it.unibs.elaborato.v2;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Gestisce l'archivio delle Proposte pubblicate (Aperte).
	 */
	public class Bacheca {
        private List<Proposta> proposteAperte = new ArrayList<>();

        /**
         * Aggiunge una proposta aperta alla bacheca.
         * @param p La proposta da includere.
	 */
	// Precondizione: p != null
	public void aggiungi(Proposta p) {
                proposteAperte.add(p);
        }
	// Postcondizione: collezione.contains(proposta) == true

        /**
         * @return L'elenco integrale delle proposte in bacheca.
         */
	public List<Proposta> getTutte() {
                return proposteAperte;
        }
	// Postcondizione: return != null

        /**
         * Estrae le proposte legate a una categoria specifica.
         * @param nomeCategoria Stringa target corrispondente al nome categoria.
         * @return Una sublist delle sole proposte aderenti al filtro.
	 */
	// Precondizione: nomeCategoria != null
	public List<Proposta> filtraPerCategoria(String nomeCategoria) {
                return proposteAperte.stream()
                                .filter(p -> p.getCategoria().getNome().equalsIgnoreCase(nomeCategoria))
                                .collect(Collectors.toList());
        }
	// Postcondizione: proposte.foreach(p.cat == cat) == true

        /**
         * Elimina tutte le proposte svuotando la bacheca.
         */
	public void svuota() {
                proposteAperte.clear();
        }
	// Postcondizione: proposteAperte.isEmpty() == true
}

