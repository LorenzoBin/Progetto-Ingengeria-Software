package it.unibs.elaborato.v2;

/**
 * Rappresenta un Campo Specifico assegnato a una particolare Categoria.
 * <p>
 * A differenza di campi base o comuni che valgono per tutto il sistema, i campi specifici 
 * sono peculiarit che permettono di acquisire dettagli necessari limitatamente 
 * a una tipologia di iniziativa (ad esempio: "Squadre partecipanti" per un torneo di calcio).
 * </p>
	 */
	public class CampoSpecifico extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Specifico per una categoria.
	 * 
	 * @param nome                 Il nome descrittivo del campo ristretto.
	 * @param obbligatorio {@code true} se la sua compilazione per questa categoria e' obbligatoria.
	 * 
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public CampoSpecifico(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
	// Invariante: nome != null && !nome.trim().isEmpty()
	// Postcondizione: campoSpecifico != null && isCoerente(input)
}

