﻿package it.unibs.elaborato.v2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import it.unibs.fp.mylib.InputDati;

/**
 * Versione 2.
 */
	public class Main {
	
	private static final String FILE_CREDENZIALI = "credenziali.txt";
	private static final String FILE_CAMPI_BASE = "campi_base.txt";
	private static final String FILE_DATI_SISTEMA = "dati_sistema.txt";

	public static void main(String[] args) {
		Configuratore configuratore = new Configuratore();
		SessioneLogin sessioneLogin = new SessioneLogin();

		try {
			sessioneLogin.carica(FILE_CREDENZIALI);
			String utenteAttivo = eseguiLogin(sessioneLogin);

			configuratore.caricaOInizializzaCampiBase(FILE_CAMPI_BASE);
			configuratore.caricaDati(FILE_DATI_SISTEMA);

			eseguiMenuPrincipale(configuratore, sessioneLogin, utenteAttivo);

		} catch (IOException e) {
			System.out.println("Errore critico durante l'accesso ai file: " + e.getMessage());
		}
	}

	/**
	 * Gestisce l'intero ciclo interattivo di login e registrazione per primo accesso.
	 * 
	 * @param sessioneLogin Gestore sessione iniettato ad hoc.
	 * @return l'username dell'utente che ha effettuato l'accesso con successo.
	 * @throws IOException Errore fatale di scrittura del primo admin.
	 * 
	 */
	// Precondizione: sessioneLogin != null
	private static String eseguiLogin(SessioneLogin sessioneLogin) throws IOException {
		String utenteAttivo = null;

		while (utenteAttivo == null) {
			System.out.println("\n--- ACCESSO SISTEMA ---");
			String usernameInserito = InputDati.leggiStringaNonVuota("Username: ");
			String passwordInserita = InputDati.leggiStringaNonVuota("Password: ");

			if (sessioneLogin.isMasterAdmin(usernameInserito, passwordInserita)) {
				utenteAttivo = registraNuovoConfiguratore(sessioneLogin);
			} else if (sessioneLogin.autentica(usernameInserito, passwordInserita)) {
				utenteAttivo = usernameInserito;
				System.out.println("Benvenuto, " + utenteAttivo + "!");
			} else {
				System.out.println(">>> Errore: Credenziali errate. Riprova.");
			}
		}
		
		return utenteAttivo;
	}
	// Postcondizione: return == stringa(utente)

	/**
	 * Procedura guidata step-by-step per la registrazione di un nuovo utente e relativo autologin finale.
	 * 
	 * @param sessioneLogin Sessione in modifica.
	 * @return Stringa nome utente finale validato e storicizzato nel filesystem.
	 * @throws IOException Crash file utenze di rete eventuale.
	 * 
	 */
	// Precondizione: sessioneLogin != null
	private static String registraNuovoConfiguratore(SessioneLogin sessioneLogin) throws IOException {
		System.out.println("\n--- REGISTRAZIONE NUOVO CONFIGURATORE ---");
		String nuovoUsername;
		
		while (true) {
			nuovoUsername = InputDati.leggiStringaNonVuota("Inserisci Username personale: ");
			
			if (!sessioneLogin.esisteGia(nuovoUsername)) {
				break;
			}
			System.out.println("Errore: username gia' in uso o riservato!");
		}
		
		String nuovaPassword = InputDati.leggiStringaNonVuota("Inserisci Password personale: ");

		sessioneLogin.registraNuovo(nuovoUsername, nuovaPassword);
		sessioneLogin.salva(FILE_CREDENZIALI);
		
		System.out.println("Configuratore '" + nuovoUsername + "' registrato con successo.\n");
		return nuovoUsername;
	}
	// Postcondizione: login.contains(utente) == true

	/**
	 * Ciclo principale interattivo (Read-Evaluate-Print Loop) per la gestione applicativa.
	 * 
	 * @param conf                     Database logico runtime.
	 * @param login                    Per il salvataggio automatico credenziali.
	 * @param user                     Nome login attivo (grafico).
	 * @throws IOException e' Errore di salvataggio fatale.
	 * 
	 */
	// Precondizione: conf != null && login != null
	private static void eseguiMenuPrincipale(Configuratore conf, SessioneLogin login, String user) throws IOException {
		boolean esciMenu = false;
		
		while (!esciMenu) {
			stampaVociMenu(user);
			int scelta = InputDati.leggiIntero("Scegli un'opzione: ");
			
			switch (scelta) {
				case 0: esciMenu = esciESalva(conf, login);
					break;
				case 1: if (conf.getCategorie().isEmpty()) {
						System.out.println("\n[AVVISO] Non e' presente alcuna categoria al momento.");
					} else {
						conf.getCategorie().forEach(categoria -> categoria.visualizza(conf.getCampiBase(), conf.getCampiComuni()));
					}
					break;
				case 2: gestisciCategorie(conf);
					break;
				case 3: gestisciCampiComuni(conf);
					break;
				case 4: gestisciCampiSpecifici(conf);
					break;
				case 5: creaNuovaProposta(conf);
					break;
				case 6: gestisciBozze(conf);
					break;
				case 7: String nCat = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria da cercare: ");
					conf.visualizzaBachecaFiltrata(nCat);
					break;
				case 8: conf.visualizzaBachecaIntera();
					break;
				default: System.out.println("Opzione non valida. Scegliere un numero da 0 a 8.");
					break;
			}
		}
	}
	// Postcondizione: menu == chiuso && scritture == saldate

	/**
	 * Metodo grafico di terminale.
	 * @param utenteAttivo string passata per intestazione
	 */
	// Precondizione: Nessuna
	private static void stampaVociMenu(String utenteAttivo) {
		System.out.println("\n========================================");
		System.out.println(" CONFIGURATORE ATTIVO: " + utenteAttivo);
		System.out.println("========================================");
		System.out.println("1. Visualizza Categorie e Campi");
		System.out.println("2. Gestione Categorie (Aggiungi/Rimuovi)");
		System.out.println("3. Gestione Campi Comuni (Aggiungi/Rimuovi/Modifica)");
		System.out.println("4. Gestione Campi Specifici di una Categoria");
		System.out.println("5. Crea Nuova Proposta (Salva in Bozza, Valida)");
		System.out.println("6. Pubblica una Bozza in Bacheca (Rendi Aperta)");
		System.out.println("7. Visualizza Bacheca per Categoria");
		System.out.println("8. Visualizza Intera Bacheca");
		System.out.println("0. Salva ed Esci");
	}

	/**
	 * Routine innescata allo shiftout per confermare le logiche V2 su persistenza limitata.
	 * @param conf istanza
	 * @param login auth ref
	 * @throws IOException fallisce se root protetta.
	 * @return trigger booleano
	 */
	// Precondizione: conf != null && login != null
	private static boolean esciESalva(Configuratore conf, SessioneLogin login) throws IOException {
		conf.salvaDati(FILE_DATI_SISTEMA);
		login.salva(FILE_CREDENZIALI);
		System.out.println("Dati salvati correttamente. Arrivederci!");
		System.out.println("NOTA: Come da regole del sistema, qualsiasi proposta salvata in BOZZA e non e' ancora pubblicata in bacheca e' andata distrutta.");
		return true;
	}
	// Postcondizione: return == true && dati == salvati

	/** 
	 * Sottomenu categorie.
	 * @param conf ref al database.
	 */
	// Precondizione: conf != null
	private static void gestisciCategorie(Configuratore conf) {
		int scelta = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\nScegli (1 o 2): ", 1, 2);
		String nCat = InputDati.leggiStringaNonVuota("Inserisci Nome Categoria: ");
		
		if (scelta == 1) {
			conf.creaCategoria(nCat);
			System.out.println("Categoria aggiunta (o gia' esistente).");
		} else {
			conf.rimuoviCategoria(nCat);
			System.out.println("Categoria rimossa (se esisteva).");
		}
	}

	/** 
	 * Sottomenu campi comuni promiscui.
	 * @param conf ref al database.
	 */
	// Precondizione: conf != null
	private static void gestisciCampiComuni(Configuratore conf) {
		int scelta = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\n 3. Modificare obbligatorieta'\nScegli (1, 2 o 3): ", 1, 3);
		String nCamp = InputDati.leggiStringaNonVuota("Inserisci Nome Campo Comune: ");
		
		if (scelta == 1) {
			boolean obbl = InputDati.yesOrNo("Il campo e' obbligatorio?");
			conf.aggiungiCampoComune(nCamp, obbl);
			System.out.println("Campo Comune aggiunto.");
		} else if (scelta == 2) {
			conf.rimuoviCampoComune(nCamp);
			System.out.println("Campo Comune rimosso.");
		} else {
			boolean obbl = InputDati.yesOrNo("Nuovo stato: e' obbligatorio?");
			conf.cambiaObbligatorietaComune(nCamp, obbl);
			System.out.println("obbligatorieta' aggiornata.");
		}
	}

	/** 
	 * Sottomenu estensione logica nodi campo specifici.
	 * @param conf ref al database.
	 */
	// Precondizione: conf != null
	private static void gestisciCampiSpecifici(Configuratore conf) {
		String nCat = InputDati.leggiStringaNonVuota("\nSpecificare la Categoria su cui agire: ");
		int scelta = InputDati.leggiIntero("Vuoi:\n 1. Aggiungere Campo Specifico\n 2. Rimuovere Campo Specifico\nScegli (1 o 2): ", 1, 2);
		String nCamp = InputDati.leggiStringaNonVuota("Inserisci Nome Campo: ");
		
		if (scelta == 1) {
			boolean obbl = InputDati.yesOrNo("Il campo e' obbligatorio?");
			conf.aggiungiCampoSpecifico(nCat, nCamp, obbl);
			System.out.println("Operazione eseguita.");
		} else {
			conf.rimuoviCampoSpecifico(nCat, nCamp);
			System.out.println("Operazione eseguita.");
		}
	}

	/** 
	 * Form iterativo per l'espletamento di una logica di proposta nuova V2.
	 * @param conf ref al database.
	 */
	// Precondizione: conf != null
	private static void creaNuovaProposta(Configuratore conf) {
		System.out.println("\n--- CREAZIONE NUOVA PROPOSTA ---");
		String nCat = InputDati.leggiStringaNonVuota("Seleziona la Categoria dell'iniziativa: ");

		Categoria sel = null;
		for(Categoria c : conf.getCategorie()) {
			if(c.getNome().equalsIgnoreCase(nCat)) {
				sel = c;
				break;
			}
		}

		if (sel == null) {
			System.out.println(">>> Errore: Categoria non trovata.");
			return;
		}

		Proposta p = new Proposta(sel);

		List<Campo> tutti = new ArrayList<>();
		tutti.addAll(conf.getCampiBase());
		tutti.addAll(conf.getCampiComuni());
		tutti.addAll(sel.getCampiSpecifici());

		System.out.println("Inserisci i valori richiesti (le date devono essere nel formato GG/MM/YYYY):");
		@SuppressWarnings("resource")
		java.util.Scanner tempScanner = new java.util.Scanner(System.in);
		
		for (Campo c : tutti) {
		        String val = "";
		        if (c.isObbligatorio()) {
		                val = InputDati.leggiStringaNonVuota("- " + c.getNome() + "*: ");
		        } else {
		                System.out.print("- " + c.getNome() + " (premere invio per saltare): ");
		                val = tempScanner.nextLine();
		        }
			if (!val.isBlank()) p.inserisciValore(c.getNome(), val.trim());
		}

		if (conf.validaProposta(p)) {
			conf.aggiungiBozza(p);
			System.out.println("\n>>> LA PROPOSTA E' VALIDA!");
			System.out.println(" stata salvata temporaneamente in BOZZA (Stato: VALIDA).");
			System.out.println("Usa l'opzione 6 del menu per pubblicarla in Bacheca, altrimenti andr persa alla chiusura.");
		} else {
			System.out.println("\n>>> ERRORE: La proposta non rispetta i vincoli temporali (iscrizione > oggi, data evento >= iscrizione + 2 gg) o mancano campi obbligatori.");
		}
	}
	// Postcondizione: validato == true ? bozza != null : bozza == null

	/** 
	 * Trigger di interazione tra bozze limitate in ram e bacheca.
	 * @param conf master manager class inietto
	 */
	// Precondizione: conf != null
	private static void gestisciBozze(Configuratore conf) {
		List<Proposta> bozze = conf.getBozze();
		
		if (bozze.isEmpty()) {
			System.out.println("\nNon ci sono bozze in attesa in questa sessione.");
			return;
		}

		System.out.println("\n--- BOZZE DA PUBBLICARE ---");
		for (int i = 0; i < bozze.size(); i++) {
			Proposta b = bozze.get(i);
			String id = "N/A";
			if (!conf.getCampiBase().isEmpty()) {
				id = b.getValore(conf.getCampiBase().get(0).getNome());
			}

			System.out.println("[" + (i + 1) + "] Categoria: " + b.getCategoria().getNome() + " | Identificativo: " + id);
		}

		int scelta = InputDati.leggiIntero("\nInserisci il numero della bozza da pubblicare in bacheca (0 per annullare): ", 0, bozze.size());
		if (scelta > 0) {
			conf.pubblicaBozza(scelta - 1);
			System.out.println(">>> Bozza pubblicata con successo! Ora e' visibile in Bacheca.");
		}
	}
	// Postcondizione: id.valid ? file == converted : file == unchanged
}

