package it.unibs.elaborato.v2;

import java.util.ArrayList;
import java.util.List;

/**
 * Rappresenta una Categoria che accomuna una varieta' di iniziative.
 * <p>
 * Ogni categoria viene definita dal configuratore e ha lo scopo di raggruppare iniziative
 * affini per tematica (es. "Sport", "Cultura", "Gite"). Contiene inoltre un registro
 * di {@link CampoSpecifico} dedicati unicamente a raccogliere caratteristiche dettagliate 
 * per quella singola cerchia di eventi.
 * </p>
	 */
	public class Categoria {
	
	private final String nome;
	private final List<CampoSpecifico> campiSpecifici;

	/**
	 * Costruttore per creare una nuova Categoria di base.
	 * 
	 * @param nome Il nome univoco identificativo della categoria.
	 * 
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public Categoria(String nome) {
		this.nome = nome;
		this.campiSpecifici = new ArrayList<>();
	}
	// Invariante: nome != null && campiSpecifici != null
	// Postcondizione: this.nome == nome && campi.size == 0

	/**
	 * Restituisce il nome della categoria.
	 * 
	 * @return Il nome esteso della categoria.
	 */
	 public String getNome() {
		return nome;
	}
	 // Postcondizione: return != null && !return.trim().isEmpty()

	/**
	 * Restituisce l'elenco dei campi specifici registrati della categoria.
	 * 
	 * @return Una lista di {@link CampoSpecifico}.
	 */
	 public List<CampoSpecifico> getCampiSpecifici() {
		return campiSpecifici;
	}
	 // Postcondizione: return != null

	/**
	 * Associa un nuovo campo specifico a questa categoria.
	 * 
	 * @param campoSpecifico Il {@link CampoSpecifico} da aggiungere all'archivio della categoria.
	 * 
	 */
	// Precondizione: campoSpecifico != null
	public void aggiungiCampoSpecifico(CampoSpecifico campoSpecifico) {
		this.campiSpecifici.add(campoSpecifico);
	}
	// Postcondizione: Il campo e' stato aggiunto alla lista campiSpecifici.

	/**
	 * Stampa a console in modo formattato e visivamente strutturato tutte le 
	 * configurazioni pertinenti a questa Categoria. Include il recap e la somma complessiva 
	 * dei vari domini dei campi: Base, Comuni e Specifici.
	 * 
	 * @param campiBase     La lista dei campi di base in vigore sul sistema.
	 * @param campiComuni La lista dei campi condivisibili globalmente in vigore.
	 * 
	 */
	// Precondizione: campiBase != null && campiComuni != null
	public void visualizza(List<CampoBase> campiBase, List<CampoComune> campiComuni) {
		System.out.printf("%n=== CATEGORIA: %s ===%n", nome.toUpperCase());
		System.out.println(" -> Campi Base:");
		campiBase.forEach(campo -> System.out.println(" - " + campo));
		
		System.out.println(" -> Campi Comuni:");
		campiComuni.forEach(campo -> System.out.println(" - " + campo));
		
		System.out.println(" -> Campi Specifici:");
		campiSpecifici.forEach(campo -> System.out.println(" - " + campo));
		System.out.println("==========================\n");
	}
	// Postcondizione: stout == stato.format
}

