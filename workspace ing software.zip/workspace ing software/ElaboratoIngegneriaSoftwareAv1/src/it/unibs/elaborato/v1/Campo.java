package it.unibs.elaborato.v1;

/**
 * Rappresenta la struttura astratta di base per un campo informativo.
 * Un campo rappresenta una singola informazione (es. "Luogo", "Data", "Costo") 
 * che caratterizza un'iniziativa o una categoria.
	 */
	public abstract class Campo {
	
	private final String nome;
	private boolean obbligatorio;

	/**
	 * Costruisce una nuova istanza di un Campo.
	 * 
	 * @param nome                 Il nome descrittivo del campo (es. "Quota di iscrizione").
	 * @param obbligatorio {@code true} se la compilazione del campo e' indispensabile, {@code false} se facoltativa.
	 * 
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public Campo(String nome, boolean obbligatorio) {
		this.nome = nome;
		this.obbligatorio = obbligatorio;
	}
	// Invariante: nome != null && !nome.trim().isEmpty()
	// Postcondizione: this != null && this.nome == nome && this.obbligatorio == obbligatorio

	/**
	 * Restituisce il nome descrittivo del campo.
	 * 
	 * @return Una stringa contenente il nome del campo.
	 */
	 public String getNome() {
		return nome;
	}
	 // Postcondizione: return != null && !return.trim().isEmpty()

	/**
	 * Verifica se il campo e' obbligatorio.
	 * 
	 * @return {@code true} se il campo deve essere compilato obbligatoriamente, {@code false} altrimenti.
	 */
	public boolean isObbligatorio() {
		return obbligatorio;
	}

	/**
	 * Imposta l'obbligatorieta' del campo.
	 * 
	 * @param obbligatorio Il nuovo stato di obbligatorieta' per il campo.
	 */
	 public void setObbligatorio(boolean obbligatorio) {
		this.obbligatorio = obbligatorio;
	}
	 // Postcondizione: isObbligatorio() == obbligatorio

	/**
	 * Restituisce una rappresentazione testuale del campo, comprensiva 
	 * del nome e del suo stato di obbligatorieta'.
	 * 
	 * @return Una stringa formattata rappresentante lo stato dell'oggetto.
	 */
	 public String toString() {
		String statoObbligatorieta = obbligatorio ? " [Obbligatorio]" : " [Facoltativo]";
		return nome + statoObbligatorieta;
	}
	 // Postcondizione: return != null && return.contains(nome)
}
