package it.unibs.elaborato.v1;

import java.io.IOException;
import it.unibs.fp.mylib.InputDati;

/**
 * Versione 1
 */
	public class Main {
	
	private static final String FILE_CREDENZIALI = "credenziali.txt";
	private static final String FILE_CAMPI_BASE = "campi_base.txt";
	private static final String FILE_DATI_SISTEMA = "dati_sistema.txt";

	public static void main(String[] args) {
		Configuratore configuratore = new Configuratore();
		SessioneLogin sessioneLogin = new SessioneLogin();

		try {
			sessioneLogin.carica(FILE_CREDENZIALI);
			String utenteAttivo = eseguiLogin(sessioneLogin);

			configuratore.caricaOInizializzaCampiBase(FILE_CAMPI_BASE);
			configuratore.caricaDati(FILE_DATI_SISTEMA);

			eseguiMenuPrincipale(configuratore, sessioneLogin, utenteAttivo);

		} catch (IOException e) {
			System.out.println("Errore critico durante l'accesso ai file: " + e.getMessage());
		}
	}

	/**
	 * Gestisce l'intero ciclo interattivo di login e registrazione per primo accesso 
	 * incapsulandone la sua logica e isolando dal main flow.
	 * 
	 * @param sessioneLogin Gestore sessione iniettato ad hoc.
	 * @return l'username dell'utente che ha effettuato l'accesso con successo.
	 * @throws IOException Errore fatale di scrittura del primo admin.
	 * 
	 */
	// Precondizione: sessioneLogin != null
	private static String eseguiLogin(SessioneLogin sessioneLogin) throws IOException {
		String utenteAttivo = null;

		while (utenteAttivo == null) {
			System.out.println("\n--- ACCESSO SISTEMA ---");
			String usernameInserito = InputDati.leggiStringaNonVuota("Username: ");
			String passwordInserita = InputDati.leggiStringaNonVuota("Password: ");

			if (sessioneLogin.isMasterAdmin(usernameInserito, passwordInserita)) {
				utenteAttivo = registraNuovoConfiguratore(sessioneLogin);
			} else if (sessioneLogin.autentica(usernameInserito, passwordInserita)) {
				utenteAttivo = usernameInserito;
				System.out.println("Benvenuto, " + utenteAttivo + "!");
			} else {
				System.out.println(">>> Errore: Credenziali errate. Riprova.");
			}
		}
		
		return utenteAttivo;
	}
	// Postcondizione: return == utente

	/**
	 * Procedura guidata step-by-step per la registrazione di un nuovo utente e relativo autologin finale.
	 * 
	 * @param sessioneLogin Sessione in modifica.
	 * @return Stringa nome utente finale validato e storicizzato nel filesystem.
	 * @throws IOException Crash file utenze di rete eventuale.
	 * 
	 */
	// Precondizione: sessioneLogin != null
	private static String registraNuovoConfiguratore(SessioneLogin sessioneLogin) throws IOException {
		System.out.println("\n--- REGISTRAZIONE NUOVO CONFIGURATORE ---");
		String nuovoUsername;
		
		while (true) {
			nuovoUsername = InputDati.leggiStringaNonVuota("Inserisci Username personale: ");
			
			if (!sessioneLogin.esisteGia(nuovoUsername)) {
				break;
			}
			System.out.println("Errore: username gia' in uso o riservato (non usare 'admin')!");
		}
		
		String nuovaPassword = InputDati.leggiStringaNonVuota("Inserisci Password personale: ");

		sessioneLogin.registraNuovo(nuovoUsername, nuovaPassword);
		sessioneLogin.salva(FILE_CREDENZIALI);
		
		System.out.println("Configuratore '" + nuovoUsername + "' registrato con successo.\n");
		return nuovoUsername;
	}
	// Postcondizione: login.contains(utente) == true

	/**
	 * Ciclo principale interattivo (Read-Evaluate-Print Loop) che fa da collante 
	 * per scavalcare i vari tool di configurazione in stile terminal UI.
	 * 
	 * @param configuratore        Database delle logiche dell'Iniziativa.
	 * @param sessioneLogin        Per il salvataggio automatico prima di ritornare in exit.
	 * @param utenteAttivo         Stringa di decorazione visiva dell'auth-user.
	 * @throws IOException         Errore di salvataggio a chiusura app.
	 * 
	 */
	// Precondizione: configuratore != null && sessioneLogin != null
	private static void eseguiMenuPrincipale(Configuratore configuratore, SessioneLogin sessioneLogin, String utenteAttivo) throws IOException {
		boolean esciMenu = false;
		
		while (!esciMenu) {
			stampaVociMenu(utenteAttivo);
			int scelta = InputDati.leggiIntero("Scegli un'opzione: ");
			
			switch (scelta) {
				case 0: esciMenu = esciESalva(configuratore, sessioneLogin);
					break;
				case 1: if (configuratore.getCategorie().isEmpty()) {
						System.out.println("\n[AVVISO] Non e' presente alcuna categoria al momento.");
					} else {
						configuratore.getCategorie().forEach(categoria -> categoria.visualizza(configuratore.getCampiBase(), configuratore.getCampiComuni()));
					}
					break;
				case 2: gestisciCategorie(configuratore);
					break;
				case 3: gestisciCampiComuni(configuratore);
					break;
				case 4: gestisciCampiSpecifici(configuratore);
					break;
				default: System.out.println("Opzione non valida. Scegliere un numero da 0 a 4.");
					break;
			}
		}
	}
	// Postcondizione: menu.attivo == false

	/**
	 * Renderizza i print a vista della dashboard per l'amministratore.
	 * @param utenteAttivo la label dell'utente formattata.
	 * 
	 */
	// Precondizione: Nessuna restrizione.
	private static void stampaVociMenu(String utenteAttivo) {
		System.out.println("\n========================================");
		System.out.println(" CONFIGURATORE ATTIVO: " + utenteAttivo);
		System.out.println("========================================");
		System.out.println("1. Visualizza Categorie e Campi");
		System.out.println("2. Gestione Categorie (Aggiungi/Rimuovi)");
		System.out.println("3. Gestione Campi Comuni (Aggiungi/Rimuovi/Modifica)");
		System.out.println("4. Gestione Campi Specifici di una Categoria");
		System.out.println("0. Salva ed Esci");
	}

	/**
	 * Assicura di perpetuare le configurazioni su disco prima del termine istruzioni.
	 * @return true per triggerare l'uscita sul chiamante.
	 * 
	 */
	// Precondizione: configuratore != null && sessioneLogin != null
	private static boolean esciESalva(Configuratore configuratore, SessioneLogin sessioneLogin) throws IOException {
		configuratore.salvaDati(FILE_DATI_SISTEMA);
		sessioneLogin.salva(FILE_CREDENZIALI);
		System.out.println("Dati salvati correttamente. Arrivederci!");
		return true;
	}
	// Postcondizione: return == true && dati == salvati

	/** 
	 * Sottomenu esecutivo per categorie.
	 * 
	 */
	// Precondizione: configuratore != null
	private static void gestisciCategorie(Configuratore configuratore) {
		int sceltaAzione = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\nScegli (1 o 2): ", 1, 2);
		String nomeCategoria = InputDati.leggiStringaNonVuota("Inserisci Nome Categoria: ");
		
		if (sceltaAzione == 1) {
			configuratore.creaCategoria(nomeCategoria);
			System.out.println("Categoria aggiunta (o gia' esistente).");
		} else if (sceltaAzione == 2) {
			configuratore.rimuoviCategoria(nomeCategoria);
			System.out.println("Categoria rimossa (se esisteva).");
		}
	}
	// Postcondizione: input.valid ? categoria == modified : categoria == unchanged

	/** 
	 * Sottomenu esecutivo per campi promiscui.
	 * 
	 */
	// Precondizione: configuratore != null
	private static void gestisciCampiComuni(Configuratore configuratore) {
		int sceltaAzione = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\n 3. Modificare obbligatorieta'\nScegli (1, 2 o 3): ", 1, 3);
		String nomeCampo = InputDati.leggiStringaNonVuota("Inserisci Nome Campo Comune: ");
		
		if (sceltaAzione == 1) {
			boolean eObbligatorio = InputDati.yesOrNo("Il campo e' obbligatorio?");
			configuratore.aggiungiCampoComune(nomeCampo, eObbligatorio);
			System.out.println("Campo Comune aggiunto.");
			
		} else if (sceltaAzione == 2) {
			configuratore.rimuoviCampoComune(nomeCampo);
			System.out.println("Campo Comune rimosso.");
			
		} else if (sceltaAzione == 3) {
			boolean nuovoStato = InputDati.yesOrNo("Nuovo stato: e' obbligatorio?");
			configuratore.cambiaObbligatorietaComune(nomeCampo, nuovoStato);
			System.out.println("obbligatorieta' aggiornata.");
		}
	}
	// Postcondizione: input.valid ? campi == modified : campi == unchanged

	/** 
	 * Sottomenu esecutivo per caratteristiche relegate a specifici hobby.
	 * 
	 */
	// Precondizione: configuratore != null
	private static void gestisciCampiSpecifici(Configuratore configuratore) {
		String nomeCategoria = InputDati.leggiStringaNonVuota("\nSpecificare la Categoria su cui agire: ");
		
		int sceltaAzione = InputDati.leggiIntero("Vuoi:\n 1. Aggiungere Campo Specifico\n 2. Rimuovere Campo Specifico\nScegli (1 o 2): ", 1, 2);
		String nomeCampo = InputDati.leggiStringaNonVuota("Inserisci Nome Campo: ");
		
		if (sceltaAzione == 1) {
			boolean eObbligatorio = InputDati.yesOrNo("Il campo e' obbligatorio?");
			configuratore.aggiungiCampoSpecifico(nomeCategoria, nomeCampo, eObbligatorio);
			System.out.println("Operazione eseguita.");
			
		} else if (sceltaAzione == 2) {
			configuratore.rimuoviCampoSpecifico(nomeCategoria, nomeCampo);
			System.out.println("Operazione eseguita.");
		}
	}
	// Postcondizione: find(nome) ? categorie[nome] == modificato : state == inalterato
}

