﻿package it.unibs.elaborato.v1;

import java.io.*;
import java.util.*;

/**
 * Gestisce l'accesso al sistema, la verifica delle credenziali e
 * il salvataggio/caricamento degli utenti (Configuratori).
	 */
	public class SessioneLogin {
	
	private final Map<String, String> utentiRegistrati;
	private static final String ADMIN_MASTER = "admin";

	/**
	 * Crea un'istanza della mappa per l'autenticazione.
	 */
	public SessioneLogin() {
		this.utentiRegistrati = new HashMap<>();
	}
	// Postcondizione: archivio.size == 0

	/**
	 * Verifica se le credenziali inserite corrispondono a quelle
	 * dell'amministratore master temporaneo per la creazione di account.
	 * 
	 * @param username Il nome utente loggato.
	 * @param password La password in input.
	 * @return true se corrispondono ai parametri bypass.
	 * 
	 */
	// Precondizione: username != null && password != null
	public boolean isMasterAdmin(String username, String password) {
		return ADMIN_MASTER.equals(username) && ADMIN_MASTER.equals(password);
	}
	// Postcondizione: stato == inalterato

	/**
	 * Restituisce true se l'utente e' registrato e la password e' corretta.
	 * 
	 * @param username username.
	 * @param password assword.
	 * @return Il risultato logico dell'autenticazione.
	 * 
	 */
	// Precondizione: username != null && password != null
	public boolean autentica(String username, String password) {
		return utentiRegistrati.containsKey(username) && utentiRegistrati.get(username).equals(password);
	}

	/**
	 * Salva un nuovo configuratore.
	 * 
	 * @param username Nome.
	 * @param password Password del nome.
	 * @return false se lo username e' gia' registrato (vietato duplicato), true in caso di successo.
	 * 
	 */
	// Precondizione: username != null && password != null && !username.trim().isEmpty()
	public boolean registraNuovo(String username, String password) {
		if (esisteGia(username)) {
			return false;
		}
		
		utentiRegistrati.put(username, password);
		return true;
	}
	// Postcondizione: success ? mappa.size == mappa.size + 1 : mappa.size == unchanged

	/**
	 * Controlla che uno username sia in utilizzo o se sia vietato (admin).
	 * 
	 * @param username La mail di login o nome utente.
	 * @return Un test fallito se gia' occupato o prenotato.
	 * 
	 */
	// Precondizione: username != null
	public boolean esisteGia(String username) {
		return utentiRegistrati.containsKey(username) || ADMIN_MASTER.equalsIgnoreCase(username);
	}

	/**
	 * Salva in modo persistente le credenziali nel file di testo specificato.
	 * 
	 * @param filePath Path del file txt destinazione.
	 * @throws IOException in caso di problema in scrittura.
	 * 
	 */
	// Precondizione: filePath != null && !filePath.isEmpty()
	public void salva(String filePath) throws IOException {
		try (PrintWriter writer = new PrintWriter(new FileWriter(filePath))) {
			for (Map.Entry<String, String> entry : utentiRegistrati.entrySet()) {
				writer.println(entry.getKey() + ";" + entry.getValue());
			}
		}
	}
	// Postcondizione: credenziali == saved

	/**
	 * Carica in memoria gli account registrati dal file di testo.
	 * 
	 * @param filePath Path del file txt in cui ci sono gli auth.
	 * @throws IOException in caso non via sia caricamento.
	 * 
	 */
	// Precondizione: filePath != null && !filePath.isEmpty()
	public void carica(String filePath) throws IOException {
		File fileCredenziali = new File(filePath);
		
		if (!fileCredenziali.exists()) {
			return;
		}
		
		try (BufferedReader reader = new BufferedReader(new FileReader(fileCredenziali))) {
			String lineaLetta;
			while ((lineaLetta = reader.readLine()) != null) {
				String[] parti = lineaLetta.split(";");
				if (parti.length >= 2) {
					String username = parti[0];
					String password = parti[1];
					utentiRegistrati.put(username, password);
				}
			}
		}
	}
	// Postcondizione: file.exists ? utenti.size >= utenti.size : utenti.size == unchanged
}

