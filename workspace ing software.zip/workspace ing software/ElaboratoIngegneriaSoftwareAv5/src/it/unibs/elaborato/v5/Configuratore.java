package it.unibs.elaborato.v5;

import java.io.*;
import java.util.*;
import java.time.LocalDate;
import it.unibs.fp.mylib.InputDati;

/**
 * Logica di business e backoffice operativo. Ospita anche l'engine simulativo cronologico.
	 */
	public class Configuratore {
	private List<CampoBase> campiBase;
	private List<CampoComune> campiComuni;
	private Map<String, Categoria> categorie;
	private Bacheca bachecaReale;
	private List<Proposta> bozze;
	private Map<String, Fruitore> mappaFruitori;

	/**
	 */
	public Configuratore() {
		this.campiBase = new ArrayList<>();
		this.campiComuni = new ArrayList<>();
		this.categorie = new HashMap<>();
		this.bachecaReale = new Bacheca();
		this.bozze = new ArrayList<>();
		this.mappaFruitori = new HashMap<>();
	}
	// Postcondizione: attributi != null
	// Postcondizione: root != null

	/**
	 * Ripristino o Inserimento guidato radici.
	 * @param path dest 
	 * @param ruolo Role check string 
	 * @throws IOException in malfunzioni fatali
	 */
	// Precondizione: path != null && ruolo != null
	public void caricaOInizializzaCampiBase(String path, String ruolo) throws IOException {
		File f = new File(path);
		if (!f.exists()) f.createNewFile();
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String l;
			while ((l = br.readLine()) != null) if (!l.trim().isEmpty()) campiBase.add(new CampoBase(l.trim()));
		}
		
		if (campiBase.isEmpty()) {
			if ("CONFIGURATORE".equals(ruolo)) {
				System.out.println("\n[SETUP INIZIALE] Inserisci i nomi per i Campi Base.\nI campi 'Termine ultimo di iscrizione', 'Data' e 'Data conclusiva' sono raccomandati logicamente.");
				try (PrintWriter pw = new PrintWriter(new FileWriter(f))) {
					while (true) {
						String n = InputDati.leggiStringaNonVuota("Nome campo base (o 'FINE'): ");
						if (n.equalsIgnoreCase("FINE")) break;
						campiBase.add(new CampoBase(n)); 
						pw.println(n);
					}
				}
			} else {
				System.out.println("\n[AVVISO] Il sistema non e' ancora stato inizializzato da un Configuratore. La bacheca sara' vuota.");
			}
		}
	}
	// Postcondizione: Se file vuoto ed e' presente Configuratore avvia il setup via InputDati.

	/** @return Get array cb <p><b>Postcondizioni:</b> {@code return != null}</p> */
	public List<CampoBase> getCampiBase() { return campiBase; }
	/** @return Get array cc <p><b>Postcondizioni:</b> {@code return != null}</p> */
	public List<CampoComune> getCampiComuni() {	return campiComuni;	}
	/** @return Get cat.vals <p><b>Postcondizioni:</b> {@code return != null}</p> */
	public Collection<Categoria> getCategorie() { return categorie.values(); }
	/** @return Get bacheca manager object <p><b>Postcondizioni:</b> {@code return != null}</p> */
	public Bacheca getBacheca() { return bachecaReale; }

	/**
	 * @param username Codice utente univoco
	 * @return Interfaccia personal space o nuovo hook Fruitore se mai visto
	 */
	// Precondizione: username != null
	public Fruitore getFruitore(String username) {
		mappaFruitori.putIfAbsent(username, new Fruitore(username));
		return mappaFruitori.get(username);
	}

	// Metodi Categorie DB RAM
	public void aggiungiCampoComune(String n, boolean o) { campiComuni.add(new CampoComune(n, o)); }
	public void rimuoviCampoComune(String n) { campiComuni.removeIf(c -> c.getNome().equalsIgnoreCase(n)); }
	// Postcondizione: found ? list.size == list.size - 1 : state == inalterato
	public void cambiaObbligatorietaComune(String n, boolean o) { for (CampoComune c : campiComuni) if (c.getNome().equalsIgnoreCase(n)) c.setObbligatorio(o); }
	// Postcondizione: found ? campo.modificato == true : state == inalterato	// Precondizione: n != null && !n.isBlank()

	public void creaCategoria(String n) { categorie.putIfAbsent(n, new Categoria(n)); }
	// Postcondizione: !exists ? hashmap.containsKey(nome) == true : state == inalterato
	public void rimuoviCategoria(String n) { categorie.remove(n); }
	// Postcondizione: Array category key !piu' rintracciabile	// Precondizione: n != null && cat != null

	public void aggiungiCampoSpecifico(String cat, String n, boolean o) { if (categorie.containsKey(cat)) categorie.get(cat).aggiungiCampoSpecifico(new CampoSpecifico(n, o)); }
	// Postcondizione: cat == match ? class.list == salvata : class.list == unchanged	// Precondizione: n != null && cat != null

	public void rimuoviCampoSpecifico(String cat, String n) { if (categorie.containsKey(cat)) categorie.get(cat).getCampiSpecifici().removeIf(c -> c.getNome().equalsIgnoreCase(n)); }
	// Postcondizione: list.size == 0

	/**
	 * Esegue cross-check rigorosissimi temporali tra le date inserite per l'Apertura.
	 * @param p Elemento da scrutare 
	 * @return Se eleggibile boolean (True OK).
	 */
	// Precondizione: p != null
	public boolean validaProposta(Proposta p) {
		for (CampoBase cb : campiBase)
			if (p.getValore(cb.getNome()) == null || p.getValore(cb.getNome()).isBlank()) return false;
		for (CampoComune cc : campiComuni)
			if (cc.isObbligatorio() && (p.getValore(cc.getNome()) == null || p.getValore(cc.getNome()).isBlank())) return false;
		for (CampoSpecifico cs : p.getCategoria().getCampiSpecifici())
			if (cs.isObbligatorio() && (p.getValore(cs.getNome()) == null || p.getValore(cs.getNome()).isBlank())) return false;
		LocalDate t = ValidatoreData.parse(p.getValore("Termine ultimo di iscrizione"));
		LocalDate d = ValidatoreData.parse(p.getValore("Data"));
		return ValidatoreData.isTermineValido(t) && ValidatoreData.isDistanzaMinimaRispettata(t, d);
	}

	/**
	 * @param p Proposta 
	 */
	// Precondizione: p != null
	public void aggiungiBozza(Proposta p) {
		if (validaProposta(p)) {
			p.setStato("Valida");
			bozze.add(p);
		}
	}
	// Postcondizione: stato == mutato && bozze.size == bozze.size + 1

	public List<Proposta> getBozze() { return bozze; }

	/**
	 * @param indice Puntatore
	 * @return Vero se range index OK e trasferita alla Bacheca persistant
	 */
	// Precondizione: indice >= 0
	public boolean pubblicaBozza(int indice) {
		if (indice >= 0 && indice < bozze.size()) {
			Proposta p = bozze.remove(indice);
			p.setStato("Aperta");
			bachecaReale.aggiungi(p);
			return true;
		}
		return false;
	}	// Precondizione: nomeCat != null


	public void visualizzaBachecaFiltrata(String nomeCat) {
		List<Proposta> filtrate = bachecaReale.filtraPerCategoria(nomeCat);
		if (filtrate.isEmpty()) System.out.println("Nessuna proposta aperta trovata in quella Categoria.");
		else filtrate.forEach(System.out::println);
	}
	// Postcondizione: sistema == unchanged

	public void visualizzaBachecaIntera() {
		bachecaReale.getAperte().forEach(System.out::println);
	}
	// Postcondizione: stream == unchanged

	/**
	 * MOTORE SIMULATIVO v4. All'avvio attraversa la Bacheca e checka la soglia critica del term iscrizioni.
	 * 
	 */
	// Precondizione: Tutte le proposte lette sono popolate.
	public void aggiornaStatiEInviaNotifiche() {
		LocalDate oggi = LocalDate.now();
		for (Proposta p : bachecaReale.getTutte()) {
			String stato = p.getStatoAttuale();
			
			if (stato.equals("Aperta")) {
				LocalDate scadenza = ValidatoreData.parse(p.getValore("Termine ultimo di iscrizione"));
				
				if (scadenza != null && oggi.isAfter(scadenza)) {
					if (p.getIscritti().size() == p.getMaxPartecipanti()) {
						p.setStato("Confermata");
						
						// String cast sicuro con getOrDefault null pointer prevention
						String vT = p.getValore("Titolo"); 
						String vC = p.getValore("Data conclusiva");
						String vD = p.getValore("Data");
						String vO = p.getValore("Ora");
						String vL = p.getValore("Luogo");
						String vQ = p.getValore("Quota individuale");

						String promemoria = String.format("L'iniziativa '%s' e' CONFERMATA! Promemoria -> Data Inizio: %s, Data Fine: %s, Ora: %s, Luogo: %s, Quota: %s.", 
							vT != null ? vT : "Senza Titolo", vD, vC != null ? vC : "-", vO, vL, vQ);
						inviaNotificaA(p.getIscritti(), promemoria);
					} else {
						p.setStato("Annullata");
						inviaNotificaA(p.getIscritti(), "L'iniziativa '" + p.getValore("Titolo") + "' e' stata ANNULLATA per mancato raggiungimento limite gruppo.");
					}
				}
			} 
			else if (stato.equals("Confermata")) {
				String dcStr = p.getValore("Data conclusiva");
				LocalDate fine = (dcStr != null && !dcStr.isBlank()) ? ValidatoreData.parse(dcStr) : ValidatoreData.parse(p.getValore("Data"));
				
				if (fine != null && oggi.isAfter(fine)) {
					p.setStato("Conclusa");
				}
			}
		}
	}
	// Postcondizione: stato == STORICO && notifiche.sent == true

	/**
	 * Broadcaster Loop di notifiche
	 * @param iscritti targets code list
	 * @param messaggio Body del telegramma
	 * e' // Turbo
	 */
	// Precondizione: iscritti != null && messaggio != null
	private void inviaNotificaA(List<String> iscritti, String messaggio) {
		Notifica n = new Notifica(messaggio, LocalDate.now());
		for (String username : iscritti) {
			getFruitore(username).aggiungiNotifica(n);
		}
	}
	// Postcondizione: mailbox.size == mailbox.size + 1

	/**
	 * Logica V4: Conferma disdetta utente inviando la conferma scritta personale.
	 * @param p Proposta target
	 * @param username Richiedente
	 * @return Se rimosso con successo
	 */
	// Precondizione: p != null && username != null
	public boolean disdiciIscrizione(Proposta p, String username) {
		if (p.disdici(username)) {
			Notifica n = new Notifica("Hai DISDETTO con successo la tua iscrizione per '" + p.getValore("Titolo") + "'.", LocalDate.now());
			getFruitore(username).aggiungiNotifica(n);
			return true;
		}
		return false;
	}

	/**
	 * Logica V4: Trasferisce in Ritirata notiziando gli sfortunati aderenti.
	 * @param p Elemento target
	 * @return Successo booleano
	 */
	// Precondizione: p != null
	public boolean ritiraProposta(Proposta p) {
		if (p.puoEssereRitirata()) {
			p.setStato("Ritirata");
			String avviso = String.format("ATTENZIONE: L'iniziativa '%s' (prevista per il %s) e' stata ritirata dal configuratore.", 
					p.getValore("Titolo"), p.getValore("Data"));
			inviaNotificaA(p.getIscritti(), avviso);
			return true;
		}
		return false;
	}
	// Postcondizione: stato == "Ritirata" && iscritti.locked == true

	// --- IMPORTAZIONE BATCH (V5) ---

	/**
	 * Permette al configuratore di caricare categorie, campi e bozze in maniera massiva
	 * leggendo un file testuale generato dal back-end.
	 * 
	 * @param pathFile Il percorso al file batch da interpretare.
	 */
	public void importaDaBatch(String pathFile) {
		File f = new File(pathFile);
		if (!f.exists()) {
			System.out.println("Errore: Il file batch specificato ('" + pathFile + "') non esiste.");
			return;
		}

		int righeLette = 0, categorieAggiunte = 0, comuniAggiunti = 0, bozzeAggiunte = 0;

		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String linea;
			while ((linea = br.readLine()) != null) {
				if (linea.trim().isEmpty() || linea.startsWith("//")) continue; 
				
				String[] parti = linea.split(";", 3);
				String tipo = parti[0].trim().toUpperCase();

				try {
					switch (tipo) {
						case "COMUNE": if (parti.length >= 3) {
								aggiungiCampoComune(parti[1].trim(), Boolean.parseBoolean(parti[2].trim()));
								comuniAggiunti++;
							}
							break;

						case "CATEGORIA": if (parti.length >= 2) {
								String nomeCat = parti[1].trim();
								creaCategoria(nomeCat);
								if (parti.length == 3) {
									String[] campiSpec = parti[2].split(";");
									for (String cs : campiSpec) {
										String[] datiCampo = cs.split(",");
										if (datiCampo.length == 2) aggiungiCampoSpecifico(nomeCat, datiCampo[0].trim(), Boolean.parseBoolean(datiCampo[1].trim()));
									}
								}
								categorieAggiunte++;
							}
							break;

						case "PROPOSTA": if (parti.length == 3) {
								String nomeCat = parti[1].trim();
								Categoria cat = categorie.get(nomeCat);
								if (cat != null) {
									Proposta p = new Proposta(cat);
									String[] coppie = parti[2].split("~");
									for (String coppia : coppie) {
										String[] kv = coppia.split("=", 2);
										if (kv.length == 2) p.inserisciValore(kv[0].trim(), kv[1].trim());
									}
									if (validaProposta(p)) {
										aggiungiBozza(p);
										bozzeAggiunte++;
									} else {
										System.out.println(" [!] Riga " + (righeLette + 1) + ": Proposta scartata (Campi mancanti o vincoli date errati).");
									}
								} else {
									System.out.println(" [!] Riga " + (righeLette + 1) + ": Categoria '" + nomeCat + "' inesistente a sistema.");
								}
							}
							break;

						default: System.out.println(" [!] Riga " + (righeLette + 1) + ": Descrittore ignorato ('" + tipo + "').");
					}
				} catch (Exception e) { System.out.println(" [!] Parsing fallito alla riga " + (righeLette + 1)); }
				righeLette++;
			}
			System.out.println("\n>>> IMPORTAZIONE BATCH COMPLETATA CON SUCCESSO!");
			System.out.println("- Campi Comuni generati: e' " + comuniAggiunti);
			System.out.println("- Nuove Categorie gestite: " + categorieAggiunte);
			System.out.println("- Nuove Bozze Proposte: " + bozzeAggiunte);

		} catch (IOException e) { System.out.println("Errore formale di input output batch: " + e.getMessage()); }
	}
	// Postcondizione: memoria == caricata && showErrors(malformate)

	// --- SALVATAGGIO E CARICAMENTO CSV-LIKE --- //

	/**
	 * Esporta DB v4
	 * @param path dest output path locale
	 * @throws IOException in failed write perm
	 */
	// Precondizione: path != null
	public void salvaDati(String path) throws IOException {
		try (PrintWriter pw = new PrintWriter(new FileWriter(path))) {
			pw.println("COMUNI");
			for (CampoComune cc : campiComuni) pw.println(cc.getNome() + ";" + cc.isObbligatorio());
			pw.println("CATEGORIE");
			for (Categoria cat : categorie.values()) {
				pw.print(cat.getNome());
				for (CampoSpecifico cs : cat.getCampiSpecifici()) pw.print(";" + cs.getNome() + "," + cs.isObbligatorio());
				pw.println();
			}
			pw.println("ARCHIVIO_PROPOSTE");
			for (Proposta p : bachecaReale.getTutte()) pw.println(p.esportaPerArchivio());
			pw.println("FRUITORI_NOTIFICHE");
			for (Fruitore f : mappaFruitori.values()) {
				pw.print(f.getUsername());
				for (Notifica n : f.getSpazioPersonale()) pw.print("##" + ValidatoreData.format(n.getData()) + "||" + n.getMessaggio());
				pw.println();
			}
		}
	}

	private LocalDate parseDataSicura(String dataString) {
		LocalDate dataFormatItaliano = ValidatoreData.parse(dataString);
		if (dataFormatItaliano != null) return dataFormatItaliano;
		try { return LocalDate.parse(dataString); } catch (Exception e) { return LocalDate.now(); }
	}

	/**
	 * Rilegge v4 DB Text File
	 * @param path URI local
	 * @throws IOException Fault hard disk
	 */
	// Precondizione: File integrita' OK.
	public void caricaDati(String path) throws IOException {
		File f = new File(path);
		if (!f.exists()) return;
		try (BufferedReader br = new BufferedReader(new FileReader(f))) {
			String sez = "", l;
			while ((l = br.readLine()) != null) {
				if (l.equals("COMUNI") || l.equals("CATEGORIE") || l.equals("ARCHIVIO_PROPOSTE") || l.equals("FRUITORI_NOTIFICHE")) {
					sez = l; continue;
				}
				if (sez.equals("COMUNI")) {
					String[] p = l.split(";");
					campiComuni.add(new CampoComune(p[0], Boolean.parseBoolean(p[1])));
				} else if (sez.equals("CATEGORIE")) {
					String[] p = l.split(";");
					Categoria c = new Categoria(p[0]);
					for (int i = 1; i < p.length; i++) {
						String[] d = p[i].split(",");
						c.aggiungiCampoSpecifico(new CampoSpecifico(d[0], Boolean.parseBoolean(d[1])));
					}
					categorie.put(c.getNome(), c);
				} else if (sez.equals("ARCHIVIO_PROPOSTE")) {
					String[] p = l.split("##");
					Categoria cat = categorie.get(p[0]);
					if (cat != null) {
						Proposta prop = new Proposta(cat);
						if (p.length > 1 && !p[1].isBlank()) {
							for (String val : p[1].split("~")) {
								String[] kv = val.split("=", 2);
								if (kv.length == 2) prop.inserisciValore(kv[0], kv[1]);
							}
						}
						if (p.length > 2 && !p[2].isBlank()) {
							for (String st : p[2].split("~")) {
								String[] kv = st.split("=", 2);
								if (kv.length == 2) prop.getStoricoStati().add(new RecordStato(kv[0], parseDataSicura(kv[1])));
							}
						}
						if (p.length > 3 && !p[3].isBlank()) {
							for (String is : p[3].split("~")) {
								if (!is.isBlank()) prop.getIscritti().add(is);
							}
						}
						bachecaReale.aggiungi(prop);
					}
				} else if (sez.equals("FRUITORI_NOTIFICHE")) {
					String[] p = l.split("##");
					Fruitore fr = getFruitore(p[0]);
					for (int i = 1; i < p.length; i++) {
						String[] n = p[i].split("\\|\\|");
						if (n.length == 2) fr.aggiungiNotifica(new Notifica(n[1], parseDataSicura(n[0])));
					}
				}
			}
		}
	}
	// Postcondizione: file.ok ? cache == reloaded : cache == empty
}

