package it.unibs.elaborato.v5;

public class CampoSpecifico extends Campo {	// Precondizione: nome != null && !nome.trim().isEmpty()

	public CampoSpecifico(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
	// Postcondizione: campoSpecifico != null && isCoerente(input)
	// Invariante: nome != null && !nome.trim().isEmpty()
}
