package it.unibs.elaborato.v5;

/**
 * Rappresenta un Campo Comune nel sistema delle iniziative.
 * <p>
 * I Campi Comuni sono decisi dal configuratore in fase di setup e si applicano trasversalmente
 * a tutte le categorie, sebbene la loro compilazione possa essere sia facoltativa che obbligatoria a scelta.
 * </p>
 */
public class CampoComune extends Campo {
	
	/**
	 * Costruisce un nuovo Campo Comune personalizzato.
	 * 
	 * @param nome                 Il nome descrittivo del campo comune.
	 * @param obbligatorio Lo stato di obbligatorieta' del campo, configurabile liberamente.
	 * 
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public CampoComune(String nome, boolean obbligatorio) {
		super(nome, obbligatorio);
	}
	// Invariante: nome != null && !nome.trim().isEmpty()
	// Postcondizione: campoComune != null
}
