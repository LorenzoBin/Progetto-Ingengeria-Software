﻿package it.unibs.elaborato.v5;

import java.time.LocalDate;

/**
 * Avviso formale stampato nella console del Fruitore per segnalare variazioni stato a lui legate.
	 */
	public class Notifica {
	private String messaggio;
	private LocalDate data;

	/**
	 * Istanzia una ricezione messaggio
	 * @param messaggio Corpo str testuale
	 * @param data Data stampigliata locale
	 */
	// Precondizione: messaggio != null && data != null
	public Notifica(String messaggio, LocalDate data) {
		this.messaggio = messaggio;
		this.data = data;
	}
	// Invariante: testo != null && timestamp != null
	// Postcondizione: stream != null

	/** 
	 * @return Get content text
	 */
	public String getMessaggio() {
		return messaggio;
	}
	// Postcondizione: return != null

	/** 
	 * @return Get date object
	 */
	public LocalDate getData() {
		return data;
	}
	// Postcondizione: return != null

	@Override
	public String toString() {
		return "[" + ValidatoreData.format(data) + "] " + messaggio;
	}
	// Postcondizione: return != null && return.contains(nome)
}

