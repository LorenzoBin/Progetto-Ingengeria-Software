﻿package it.unibs.elaborato.v5;

public class CampoBase extends Campo {	// Precondizione: nome != null && !nome.trim().isEmpty()

	public CampoBase(String nome) {
		super(nome, true);
	}
	// Postcondizione: this != null && this.obbligatorio == true
	// Invariante: nome != null && !nome.trim().isEmpty()

	@Override
	public void setObbligatorio(boolean obbligatorio) {
		throw new UnsupportedOperationException("I campi base sono immutabili e sempre obbligatori.");
	}
	// Postcondizione: isObbligatorio() == obbligatorio
}
