package it.unibs.elaborato.v5;

import java.util.*;
import java.util.stream.Collectors;

/**
 * Contenitore logico persistente delle iniziative pubbliche o storicizzate.
	 */
	public class Bacheca {
	private List<Proposta> proposte = new ArrayList<>();

	/**
	 * Append al calderone v4.
	 * @param p La proposta da includere.
	 */
	// Precondizione: p != null
	public void aggiungi(Proposta p) {
		proposte.add(p);
	}
	// Postcondizione: array.size == array.size + 1

	/**
	 * Ritorna l'archivio completo compreso confermate, annullate e concluse per storicizzazione e Configuratore.
	 * @return Arraylist di referenza per file export.
	 */
	public List<Proposta> getTutte() {
		return proposte;
	}
	// Postcondizione: return != null

	/**
	 * Crea un proxy stream per l'utenza che nasconde lo storico (Concluse, Annullate)
	 * In v4 la bacheca mostra SOLO quelle strettamente "Aperte" per l'iscrizione.
	 * @return List di filtered results
	 */
	public List<Proposta> getAperte() {
		return proposte.stream().filter(p -> p.getStatoAttuale().equals("Aperta")).collect(Collectors.toList());
	}
	// Postcondizione: return == readOnlyList

	/**
	 * Proxy ristretto alla label della categoria.
	 * @param nomeCategoria ID root group
	 * @return Sottoinsieme su Aperte targettato a string comparison case-insensitive.
	 */
	// Precondizione: nomeCategoria != null
	public List<Proposta> filtraPerCategoria(String nomeCategoria) {
		return getAperte().stream().filter(p -> p.getCategoria().getNome().equalsIgnoreCase(nomeCategoria))
				.collect(Collectors.toList());
	}
	// Postcondizione: return == list.filtered
}

