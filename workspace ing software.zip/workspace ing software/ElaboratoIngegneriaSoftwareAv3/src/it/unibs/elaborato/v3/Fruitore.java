package it.unibs.elaborato.v3;

import java.util.*;

/**
 * Gestisce i dati identificativi individuali di ciascun Fruitore e la sua cache di messaggi.
	 */
	public class Fruitore {
	private String username;
	private List<Notifica> spazioPersonale = new ArrayList<>();

	/**
	 * Crea il record account utente.
	 * @param username Codice utente
	 */
	// Precondizione: username != null && !username.isBlank()
	public Fruitore(String username) {
		this.username = username;
	}
	// Invariante: nome != null && categoriaInteresse != null
	// Postcondizione: obj != null && obj.string != null && queue != null

	/** 
	 * @return Identifier dell'umano
	 */
	public String getUsername() {
		return username;
	}
	// Postcondizione: return != null

	/**
	 * @return L'array volatile contenente comunicazioni amministrative e avvisi Iniziative
	 */
	public List<Notifica> getSpazioPersonale() {
		return spazioPersonale;
	}
	// Postcondizione: return != null

	/**
	 * Append message a utente
	 * @param n Oggetto strutturato del promemoria/annullamento
	 */
	// Precondizione: n != null
	public void aggiungiNotifica(Notifica n) {
		spazioPersonale.add(n);
	}
	// Postcondizione: code.size == code.size + 1 && hasNotificaPendente

	/**
	 * Rimozione da casella di posta per volere dell'utente in front-end
	 * @param index posizione numero della lista.
	 */
	// Precondizione: index >= 0
	public void rimuoviNotifica(int index) {
		if (index >= 0 && index < spazioPersonale.size())
			spazioPersonale.remove(index);
	}
	// Postcondizione: inBounds(list) ? list.size == list.size - 1 : list.size == unchanged
}

