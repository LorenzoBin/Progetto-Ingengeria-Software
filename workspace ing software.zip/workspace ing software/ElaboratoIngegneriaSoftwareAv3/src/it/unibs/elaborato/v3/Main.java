﻿package it.unibs.elaborato.v3;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import it.unibs.fp.mylib.InputDati;

/**
 * Versione 3.
 */
public class Main {
	
	private static final String FILE_CREDENZIALI = "credenziali.txt";
	private static final String FILE_CAMPI_BASE = "campi_base.txt";
	private static final String FILE_DATI_SISTEMA = "dati_sistema.txt";

	// Precondizione: args != null
	public static void main(String[] args) {
		Configuratore configuratore = new Configuratore();
		SessioneLogin sessioneLogin = new SessioneLogin();

		try {
			sessioneLogin.carica(FILE_CREDENZIALI);
			
			String[] sessione = eseguiLogin(sessioneLogin);
			String utenteAttivo = sessione[0];
			String ruoloAttivo = sessione[1];

			configuratore.caricaDati(FILE_DATI_SISTEMA);
			configuratore.caricaOInizializzaCampiBase(FILE_CAMPI_BASE, ruoloAttivo);

			configuratore.aggiornaStatiEInviaNotifiche();

			if ("CONFIGURATORE".equals(ruoloAttivo)) {
				eseguiMenuConfiguratore(configuratore, sessioneLogin, utenteAttivo);
			} else {
				eseguiMenuFruitore(configuratore, sessioneLogin, utenteAttivo);
			}

		} catch (IOException e) {
			System.out.println("Errore critico durante l'accesso ai file: " + e.getMessage());
		}
	}
	// Postcondizione: state == executed

	/**
	 * Gestisce in retrocompatibilita' V2 l'accesso, aggiungendo autologin per Fruitore.
	 * @param sessioneLogin auth manager
	 * @return Utente validato e ruolo
	 * @throws IOException in caso fail salva file
	 */
	// Precondizione: sessioneLogin != null
	private static String[] eseguiLogin(SessioneLogin sessioneLogin) throws IOException {
		String[] result = new String[2];

		while (result[0] == null) {
			System.out.println("\n--- ACCESSO SISTEMA ---");
			String usernameInserito = InputDati.leggiStringaNonVuota("Username: ");
			String passwordInserita = InputDati.leggiStringaNonVuota("Password: ");

			if (sessioneLogin.isMasterAdmin(usernameInserito, passwordInserita)) {
				result[0] = registraNuovoConfiguratore(sessioneLogin);
				result[1] = "CONFIGURATORE";
			} else {
				String ruolo = sessioneLogin.autentica(usernameInserito, passwordInserita);
				if (ruolo != null) {
					result[0] = usernameInserito;
					result[1] = ruolo;
					System.out.println("Benvenuto, " + result[0] + "!");
				} else {
					boolean registra = InputDati.yesOrNo(">>> Errore: Credenziali errate o utente non trovato. Vuoi registrarti come nuovo Fruitore con questi dati?");
					if (registra) {
						if (sessioneLogin.registraFruitore(usernameInserito, passwordInserita)) {
							sessioneLogin.salva(FILE_CREDENZIALI);
							result[0] = usernameInserito;
							result[1] = "FRUITORE";
							System.out.println("Benvenuto, " + result[0] + "!");
						} else {
							System.out.println(">>> Errore: username gia' in uso o riservato!");
						}
					}
				}
			}
		}
		
		return result;
	}
	// Postcondizione: return != null

	/**
	 * Permette a un Master Admin di registrare un nuovo utente con ruolo di Configuratore.
	 * Controllo unicita' dell'username verificando l'assenza tra gli iscritti.
	 * 
	 * @param sessioneLogin il gestore dei login per registrare le nuove credenziali.
	 * @return lo username del nuovo configuratore registrato.
	 * @throws IOException in caso di errori in scrittura sul file.
	 */
	// Precondizione: sessioneLogin != null
	private static String registraNuovoConfiguratore(SessioneLogin sessioneLogin) throws IOException {
		System.out.println("\n--- REGISTRAZIONE NUOVO CONFIGURATORE ---");
		String nuovoUsername;
		
		while (true) {
			nuovoUsername = InputDati.leggiStringaNonVuota("Inserisci Username personale: ");
			
			if (!sessioneLogin.esisteGia(nuovoUsername)) {
				break;
			}
			System.out.println("Errore: username gia' in uso o riservato!");
		}
		
		String nuovaPassword = InputDati.leggiStringaNonVuota("Inserisci Password personale: ");

		sessioneLogin.registraConfiguratore(nuovoUsername, nuovaPassword);
		sessioneLogin.salva(FILE_CREDENZIALI);
		
		System.out.println("Configuratore '" + nuovoUsername + "' registrato con successo.\n");
		return nuovoUsername;
	}
	// Postcondizione: login.contains(utente) == true

	// --- V2 COMANDI DEL CONFIGURATORE ---

	/**
	 * Loop principale che gestisce comandi a disposizione del ruolo Configuratore.
	 * Consente gestione categorie, gestione campi e creazione proposte.
	 * 
	 * @param conf l'oggetto radice con tutti i dati di sistema correnti.
	 * @param login l'oggetto responsabile del salvataggio sessione in chiusura.
	 * @param user username del configuratore attualmente collegato.
	 * @throws IOException per errori nel salvataggio in uscita.
	 */
	// Precondizione: conf != null && login != null && user != null
	private static void eseguiMenuConfiguratore(Configuratore conf, SessioneLogin login, String user) throws IOException {
		boolean esciMenu = false;
		
		while (!esciMenu) {
			stampaVociMenu(user);
			int scelta = InputDati.leggiIntero("Scegli un'opzione: ");
			
			switch (scelta) {
				case 0: esciMenu = esciESalva(conf, login);
					break;
				case 1: if (conf.getCategorie().isEmpty()) {
						System.out.println("\n[AVVISO] Non e' presente alcuna categoria al momento.");
					} else {
						conf.getCategorie().forEach(categoria -> categoria.visualizza(conf.getCampiBase(), conf.getCampiComuni()));
					}
					break;
				case 2: gestisciCategorie(conf);
					break;
				case 3: gestisciCampiComuni(conf);
					break;
				case 4: gestisciCampiSpecifici(conf);
					break;
				case 5: creaNuovaProposta(conf);
					break;
				case 6: gestisciBozze(conf);
					break;
				case 7: String nCat = InputDati.leggiStringaNonVuota("Inserisci il nome della Categoria da cercare: ");
					conf.visualizzaBachecaFiltrata(nCat);
					break;
				case 8: conf.visualizzaBachecaIntera();
					break;
				default: System.out.println("Opzione non valida. Scegliere un numero da 0 a 8.");
					break;
			}
		}
	}
	// Postcondizione: menu.attivo == false

	/**
	 * Stampa testuale del menu per il Configuratore.
	 * 
	 * @param utenteAttivo Username attivo per il banner del menu.
	 */
	// Precondizione: utenteAttivo != null
	private static void stampaVociMenu(String utenteAttivo) {
		System.out.println("\n========================================");
		System.out.println(" CONFIGURATORE ATTIVO: " + utenteAttivo);
		System.out.println("========================================");
		System.out.println("1. Visualizza Categorie e Campi");
		System.out.println("2. Gestione Categorie (Aggiungi/Rimuovi)");
		System.out.println("3. Gestione Campi Comuni (Aggiungi/Rimuovi/Modifica)");
		System.out.println("4. Gestione Campi Specifici di una Categoria");
		System.out.println("5. Crea Nuova Proposta (Salva in Bozza, Valida)");
		System.out.println("6. Pubblica una Bozza in Bacheca (Rendi Aperta)");
		System.out.println("7. Visualizza Bacheca per Categoria");
		System.out.println("8. Visualizza Intera Bacheca");
		System.out.println("0. Salva ed Esci");
	}
	// Postcondizione: stdout == menu.format

	/**
	 * Effettua il salvataggio dei dati su file ed esce distruggendo logicamente le bozze non confermate.
	 * 
	 * @param conf istanza di stato da serializzare.
	 * @param login istanza auth da serializzare.
	 * @return true per terminare il ciclo di vita del menu.
	 * @throws IOException in caso non si possa accedere in scrittura.
	 */
	// Precondizione: conf != null && login != null
	private static boolean esciESalva(Configuratore conf, SessioneLogin login) throws IOException {
		conf.salvaDati(FILE_DATI_SISTEMA);
		login.salva(FILE_CREDENZIALI);
		System.out.println("Dati salvati correttamente. Arrivederci!");
		System.out.println("NOTA: Come da regole del sistema, qualsiasi proposta salvata in BOZZA e non e' ancora pubblicata in bacheca e' andata distrutta.");
		return true;
	}
	// Postcondizione: return == true && dati == salvati

	/**
	 * Interfaccia a linea di comando delegata alla gestione semplice delle Categorie (inserimento o rimozione).
	 * 
	 * @param conf reference che esegue le operazioni interne in RAM.
	 */
	// Precondizione: conf != null
	private static void gestisciCategorie(Configuratore conf) {
		int scelta = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\nScegli (1 o 2): ", 1, 2);
		String nCat = InputDati.leggiStringaNonVuota("Inserisci Nome Categoria: ");
		
		if (scelta == 1) {
			conf.creaCategoria(nCat);
			System.out.println("Categoria aggiunta (o gia' esistente).");
		} else {
			conf.rimuoviCategoria(nCat);
			System.out.println("Categoria rimossa (se esisteva).");
		}
	}
	// Postcondizione: conf.categorie == modified

	/**
	 * Gestisce in modo interattivo la creazione, eliminazione o variazione dei campi in comune.
	 * 
	 * @param conf il Configuratore attivo con i dati esposti.
	 */
	// Precondizione: conf != null
	private static void gestisciCampiComuni(Configuratore conf) {
		int scelta = InputDati.leggiIntero("\nVuoi:\n 1. Aggiungere\n 2. Rimuovere\n 3. Modificare Obbligatorieta'\nScegli (1, 2 o 3): ", 1, 3);
		String nCamp = InputDati.leggiStringaNonVuota("Inserisci Nome Campo Comune: ");
		
		if (scelta == 1) {
			boolean obbl = InputDati.yesOrNo("Il campo e' obbligatorio?");
			conf.aggiungiCampoComune(nCamp, obbl);
			System.out.println("Campo Comune aggiunto.");
		} else if (scelta == 2) {
			conf.rimuoviCampoComune(nCamp);
			System.out.println("Campo Comune rimosso.");
		} else {
			boolean obbl = InputDati.yesOrNo("Nuovo stato: e' obbligatorio?");
			conf.cambiaObbligatorietaComune(nCamp, obbl);
			System.out.println("Obbligatorieta' aggiornata.");
		}
	}
	// Postcondizione: conf.campiComuni == modified

	/**
	 * Permette l'interazione per aggiungere o rimuovere campi da una specifica categoria.
	 * 
	 * @param conf classe di gestione con i dati del sistema.
	 */
	// Precondizione: conf != null
	private static void gestisciCampiSpecifici(Configuratore conf) {
		String nCat = InputDati.leggiStringaNonVuota("\nSpecificare la Categoria su cui agire: ");
		int scelta = InputDati.leggiIntero("Vuoi:\n 1. Aggiungere Campo Specifico\n 2. Rimuovere Campo Specifico\nScegli (1 o 2): ", 1, 2);
		String nCamp = InputDati.leggiStringaNonVuota("Inserisci Nome Campo: ");
		
		if (scelta == 1) {
			boolean obbl = InputDati.yesOrNo("Il campo e' obbligatorio?");
			conf.aggiungiCampoSpecifico(nCat, nCamp, obbl);
			System.out.println("Operazione eseguita.");
		} else {
			conf.rimuoviCampoSpecifico(nCat, nCamp);
			System.out.println("Operazione eseguita.");
		}
	}
	// Postcondizione: conf.campiSpecifici == modified

	/**
	 * Pilota la logica di compilazione di una nuova Proposta interrogando i campi dell'utente,
	 * valida il documento di proposta e, se confermato dall'engine, lo memorizza nelle bozze pronte per la pubblicazione.
	 * 
	 * @param conf reference che esegue le operazioni interne in RAM.
	 */
	// Precondizione: conf != null
	private static void creaNuovaProposta(Configuratore conf) {
		System.out.println("\n--- CREAZIONE NUOVA PROPOSTA ---");
		String nCat = InputDati.leggiStringaNonVuota("Seleziona la Categoria dell'iniziativa: ");

		Categoria sel = null;
		for(Categoria c : conf.getCategorie()) {
			if(c.getNome().equalsIgnoreCase(nCat)) {
				sel = c;
				break;
			}
		}

		if (sel == null) {
			System.out.println(">>> Errore: Categoria non trovata.");
			return;
		}

		Proposta p = new Proposta(sel);

		List<Campo> tutti = new ArrayList<>();
		tutti.addAll(conf.getCampiBase());
		tutti.addAll(conf.getCampiComuni());
		tutti.addAll(sel.getCampiSpecifici());

		System.out.println("Inserisci i valori richiesti (le date devono essere nel formato GG/MM/YYYY):");
		@SuppressWarnings("resource")
		java.util.Scanner tempScanner = new java.util.Scanner(System.in);
		
		for (Campo c : tutti) {
		        String val = "";
		        if (c.isObbligatorio()) {
		                val = InputDati.leggiStringaNonVuota("- " + c.getNome() + "*: ");
		        } else {
		                System.out.print("- " + c.getNome() + " (premere invio per saltare): ");
		                val = tempScanner.nextLine();
		        }
			if (!val.isBlank()) p.inserisciValore(c.getNome(), val.trim());
		}

		if (conf.validaProposta(p)) {
			conf.aggiungiBozza(p);
			System.out.println("\n>>> LA PROPOSTA E' VALIDA!");
			System.out.println("E' stata salvata temporaneamente in BOZZA (Stato: VALIDA).");
			System.out.println("Usa l'opzione 6 del menu per pubblicarla in Bacheca, altrimenti andra' persa alla chiusura.");
		} else {
			System.out.println("\n>>> ERRORE: La proposta non rispetta i vincoli temporali (iscrizione > oggi, data evento >= iscrizione + 2 gg) o mancano campi obbligatori.");
		}
	}
	// Postcondizione: bozza != null

	/**
	 * Mostra al Configuratore un elenco di bozze valide generate during la sessione
	 * per permetterne la pubblicazione in BACHECA con stato APERTA.
	 * 
	 * @param conf Oggetto globale con l'accesso alle bozze e alla Bacheca.
	 */
	// Precondizione: conf != null
	private static void gestisciBozze(Configuratore conf) {
		List<Proposta> bozze = conf.getBozze();
		
		if (bozze.isEmpty()) {
			System.out.println("\nNon ci sono bozze in attesa in questa sessione.");
			return;
		}

		System.out.println("\n--- BOZZE DA PUBBLICARE ---");
		for (int i = 0; i < bozze.size(); i++) {
			Proposta b = bozze.get(i);
			String id = "N/A";
			if (!conf.getCampiBase().isEmpty()) {
				id = b.getValore(conf.getCampiBase().get(0).getNome());
			}

			System.out.println("[" + (i + 1) + "] Categoria: " + b.getCategoria().getNome() + " | Identificativo: " + id);
		}

		int scelta = InputDati.leggiIntero("\nInserisci il numero della bozza da pubblicare in bacheca (0 per annullare): ", 0, bozze.size());
		if (scelta > 0) {
			conf.pubblicaBozza(scelta - 1);
			System.out.println(">>> Bozza pubblicata con successo! Ora e' visibile in Bacheca.");
		}
	}
	// Postcondizione: bozze == published

	// --- FUNZIONALITA' FRUITORE V3 ---
	
	/**
	 * Loop principale che gestisce comandi a disposizione del ruolo Fruitore.
	 * Consente visione bacheca, iscrizione a proposte e visualizzazione spazio personale.
	 * 
	 * @param conf    l'oggetto radice con tutti i dati di sistema correnti.
	 * @param login l'oggetto responsabile del salvataggio sessione in chiusura.
	 * @param user    username del fruitore attualmente collegato.
	 * @throws IOException in caso non si possa accedere ai file in scrittura.
	 */
	// Precondizione: conf != null && login != null && user != null
	private static void eseguiMenuFruitore(Configuratore conf, SessioneLogin login, String user) throws IOException {
		boolean esciMenu = false;
		Fruitore io = conf.getFruitore(user);
		
		while (!esciMenu) {
			stampaVociMenuFruitore(user, io.getSpazioPersonale().size());
			int scelta = InputDati.leggiIntero("Scegli un'opzione: ");
			
			switch (scelta) {
				case 0: conf.salvaDati(FILE_DATI_SISTEMA);
					login.salva(FILE_CREDENZIALI);
					System.out.println("Dati salvati correttamente. Arrivederci!");
					esciMenu = true;
					break;
				case 1: conf.visualizzaBachecaIntera();
					break;
				case 2: List<Proposta> aperte = conf.getBacheca().getAperte();
					if (aperte.isEmpty()) {
						System.out.println("Nessuna proposta aperta in Bacheca.");
						break;
					}

					System.out.println("\n--- PROPOSTE DISPONIBILI ---");
					for (int i = 0; i < aperte.size(); i++) {
						System.out.println("[" + (i + 1) + "] " + aperte.get(i).getValore("Titolo") + " (Cat: " + aperte.get(i).getCategoria().getNome() + ")");
					}
					int idx = InputDati.leggiIntero("Inserisci il numero a cui vuoi iscriverti (0 per annullare): ", 0, aperte.size());
					if (idx > 0) {
						if (aperte.get(idx - 1).iscrivi(user)) {
							System.out.println(">>> Iscrizione effettuata con successo!");
						} else {
							System.out.println(">>> Errore: Sei gia' iscritto, oppure l'evento ha raggiunto il limite massimo di partecipanti!");
						}
					}
					break;
				case 3: List<Notifica> not = io.getSpazioPersonale();
					if (not.isEmpty()) {
						System.out.println("Spazio personale vuoto.");
						break;
					}
					System.out.println("\n--- LE TUE NOTIFICHE ---");
					for (int i = 0; i < not.size(); i++) {
						System.out.println("[" + i + "] " + not.get(i));
					}
					int rIdx = InputDati.leggiIntero("\nVuoi cancellare una notifica? Inserisci il numero (o -1 per tornare al menu): ", -1, not.size() - 1);
					if (rIdx >= 0) {
						io.rimuoviNotifica(rIdx);
						System.out.println("Notifica rimossa.");
					}
					break;
				default: System.out.println("Opzione non valida. Scegliere un numero da 0 a 3.");
					break;
			}
		}
	}
	// Postcondizione: menu.attivo == false

	/**
	 * Stampa testuale del menu per il Fruitore mostrando il contatore notifiche.
	 * 
	 * @param utenteAttivo Username attivo per il banner del menu.
	 * @param notifiche        Quantita' di messaggi non letti in mailbox.
	 */
	// Precondizione: utenteAttivo != null
	private static void stampaVociMenuFruitore(String utenteAttivo, int notifiche) {
		System.out.println("\n========================================");
		System.out.println(" FRUITORE ATTIVO: " + utenteAttivo);
		System.out.println("========================================");
		System.out.println("1. Visualizza Bacheca (Contenuto e stato)");
		System.out.println("2. Iscriviti a una Proposta Aperta");
		System.out.println("3. Spazio Personale (Notifiche Da Leggere: " + notifiche + ")");
		System.out.println("0. Salva ed Esci");
	}
	// Postcondizione: stdout == menu.format
}
