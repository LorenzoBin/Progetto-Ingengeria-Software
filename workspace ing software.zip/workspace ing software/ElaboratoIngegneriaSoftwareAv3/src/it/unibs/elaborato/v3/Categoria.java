package it.unibs.elaborato.v3;

import java.util.*;

/**
 * Rappresenta una Categoria che accomuna una varieta' di iniziative.
 * <p>
 * Ogni categoria viene definita dal configuratore e ha lo scopo di raggruppare iniziative
 * affini per tematica (es. "Sport", "Cultura", "Gite"). Contiene inoltre un registro
 * di {@link CampoSpecifico} dedicati unicamente a raccogliere caratteristiche dettagliate 
 * per quella singola cerchia di eventi.
 * </p>
 */
public class Categoria {
	
	private final String nome;
	private final List<CampoSpecifico> campiSpecifici = new ArrayList<>();

	/**
	 * Costruttore per creare una nuova Categoria di base.
	 * 
	 * @param nome Il nome univoco identificativo della categoria.
	 */
	// Precondizione: nome != null && !nome.trim().isEmpty()
	public Categoria(String nome) {
		this.nome = nome;
	}
	// Postcondizione: this.nome == nome && campi.size == 0
	// Invariante: nome != null && campiSpecifici != null

	/**
	 * Restituisce il nome della categoria.
	 * 
	 * @return Il nome esteso della categoria.
	 */
	public String getNome() {
		return nome;
	}
	// Postcondizione: return != null && !return.trim().isEmpty()

	/**
	 * Restituisce l'elenco dei campi specifici registrati della categoria.
	 * 
	 * @return Una lista di {@link CampoSpecifico}.
	 */
	public List<CampoSpecifico> getCampiSpecifici() {
		return campiSpecifici;
	}
	// Postcondizione: return != null

	/**
	 * Associa un nuovo campo specifico a questa categoria.
	 * 
	 * @param cs Il {@link CampoSpecifico} da aggiungere all'archivio della categoria.
	 */
	// Precondizione: cs != null
	public void aggiungiCampoSpecifico(CampoSpecifico cs) {
		this.campiSpecifici.add(cs);
	}
	// Postcondizione: Il campo e' stato aggiunto alla lista campiSpecifici.

	/**
	 * Stampa a console in modo formattato e visivamente strutturato tutte le 
	 * configurazioni pertinenti a questa Categoria. Include il recap e la somma complessiva 
	 * dei vari domini dei campi: Base, Comuni e Specifici.
	 * 
	 * @param base   La lista dei campi di base in vigore sul sistema.
	 * @param comuni La lista dei campi condivisibili globalmente in vigore.
	 */
	// Precondizione: base != null && comuni != null
	public void visualizza(List<CampoBase> base, List<CampoComune> comuni) {
		System.out.println("\n--- CATEGORIA: " + nome.toUpperCase() + " ---");
		System.out.println("Campi Base: " + base);
		System.out.println("Campi Comuni: " + comuni);
		System.out.println("Campi Specifici: " + campiSpecifici);
	}
	// Postcondizione: stout == stato.format
}

